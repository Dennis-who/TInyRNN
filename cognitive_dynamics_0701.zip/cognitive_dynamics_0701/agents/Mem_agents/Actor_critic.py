import numpy as np
from scipy.special import logsumexp
from numba import jit

@jit(nopython=True)
def core_actor_critic(state, action, reward, theta, V, p, beta, lrate_theta, lrate_V, lrate_p, lrate_beta, C, scores, choice_probs, trial_log_likelihood):
    lik = 0
    for t in range(len(state)):
        s = state[t]
        a = action[t]
        r = reward[t]
        if a >= 0:
            d = beta * theta[s, :] + np.log(p)
            # d - logsumexp(d)
            d = d - d.max()
            logpolicy = d - np.log(np.sum(np.exp(d)))
            scores[t] = logpolicy
            policy = np.exp(logpolicy)  # softmax policy
            assert len(policy.shape) == 1
            assert len(p.shape) == 1
            choice_probs[t] = policy
            trial_log_likelihood[t] = logpolicy[a]
            lik = lik + logpolicy[a]
            cost = logpolicy[a] - np.log(p[a])  # policy complexity cost
            rpe = beta * r - cost - V[s]  # reward prediction error
            g = rpe * beta * (1 - policy[a])  # policy gradient
            V[s] = V[s] + lrate_V * rpe  # state value update
            if lrate_beta > 0:
                beta = beta + lrate_beta * (C - cost) * (
                        theta[s, a] - np.dot(theta[s, :], policy))
                beta = max(min(beta, 50), 0)
            if lrate_p > 0:
                p = p + lrate_p * (policy - p)
                p = p / np.sum(p)  # marginal update
            theta[s, a] = theta[s, a] + lrate_theta * g / (t + 1)  # policy parameter update
            # DV['rpe'][t] = rpe
            # DV['cost'][t] = cost
            # DV['gradient'][t] = g
            # DV['state_value'][t] = np.transpose(V)
            # DV['p_marg'][t] = p
    return lik, scores, choice_probs, trial_log_likelihood

class Actor_critic(object):
    def __init__(self, update_p=True, update_beta=False):
        super().__init__()
        self.name = 'Actor_critic'
        self.param_names = ['beta0', 'lrate_theta', 'lrate_V']
        self.params = [0.1, 0.1, 0.1]
        self.param_ranges = ['pos','unit','unit',]
        self.n_params = 3
        if update_p:
            self.param_names.append('lrate_p')
            self.params.append(0.5)
            self.param_ranges.append('unit')
            self.n_params += 1
            self.update_p = True
        else:
            self.lrate_p = 0
            self.update_p = False
        if update_beta:
            self.param_names+=['lrate_beta','C']
            self.params+=[0.1, 5]
            self.param_ranges+=['unit','pos']
            self.n_params += 2
            self.update_beta = True
        else:
            self.lrate_beta = 0
            self.C = 0
            self.update_beta = False
        self.state_vars = []

    def session_likelihood(self, session, params, get_DVs=False):
        lik = 0
        reward = session['reward']
        action = session['action']
        state = session['state']
        setsize = len(np.unique(state))  # number of distinct stimuli
        DV = dict()
        # DV['rpe'] = np.zeros([len(state)])
        # DV['cost'] = np.zeros([len(state)])
        # DV['gradient'] = np.zeros([len(state)])
        # DV['p_marg'] = np.zeros([len(state), 3])
        # DV['state_value'] = np.zeros([len(state), setsize])
        DV['trial_log_likelihood'] = np.zeros([len(state)])
        DV['scores'] = np.zeros([len(state), 3])
        DV['choice_probs'] = np.zeros([len(state), 3])
        theta = np.zeros([setsize, 3])  # policy xeters
        V = np.zeros([setsize])  # state values
        p = np.ones([3]) / 3  # marginal action probabilities
        beta = params[0]
        lrate_theta = params[1]
        lrate_V = params[2]
        if self.update_p:
            lrate_p = params[3]
            next_param = 4
        else:
            lrate_p = 0
            next_param = 3
        if self.update_beta:
            lrate_beta = params[next_param]
            C = params[next_param+1]
        else:
            lrate_beta = 0
            C = 0

        lik, DV['scores'], DV['choice_probs'], DV['trial_log_likelihood'] = core_actor_critic(
            state, action, reward, theta, V, p, beta, lrate_theta, lrate_V, lrate_p, lrate_beta, C,
                          DV['scores'], DV['choice_probs'], DV['trial_log_likelihood'])

        if get_DVs:
            return DV | {'session_log_likelihood': lik}
        else:
            return lik