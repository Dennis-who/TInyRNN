#include <torch/extension.h>
#include <vector>
#include <iostream>

std::vector<torch::Tensor> mlr_forward(
    torch::Tensor input, //[batch, input_size]
    torch::Tensor state, //[batch, hidden_size]
    torch::Tensor weight_ih, //[expand_size, input_size]
    torch::Tensor weight_hh_m, //[expand_size, hidden_size]
    torch::Tensor weight_hh_n, //[hidden_size, expand_size]
    torch::Tensor bias // [expand_size]
    ) {

    auto pre_hy = torch::mm(input, weight_ih.t()) + torch::mm(state, weight_hh_m.t()) + bias; // [batch, expand_size]
    auto hy = torch::tanh(pre_hy); // [batch, expand_size]
    auto output = torch::mm(hy, weight_hh_n.t()); // [batch, hidden_size]

    return {output, pre_hy, hy};
}

// tanh'(z) = 1 - tanh^2(z)
torch::Tensor d_tanh(torch::Tensor z) {
  return 1 - z.tanh().pow(2);
}

std::vector<torch::Tensor> mlr_backward(
    torch::Tensor grad_output, //  [batch, hidden_size]
    torch::Tensor input,
    torch::Tensor state,
    torch::Tensor weight_ih,
    torch::Tensor weight_hh_m,
    torch::Tensor weight_hh_n,
    torch::Tensor bias,
    torch::Tensor output,
    torch::Tensor pre_hy,
    torch::Tensor hy) {

    auto grad_hy = torch::mm(grad_output, weight_hh_n);
    auto grad_pre_hy = grad_hy * d_tanh(pre_hy);
    auto grad_weight_hh_n = torch::mm(grad_output.t(), hy);

    auto grad_bias = grad_pre_hy.sum(0); // Sum over batch dimension
    auto grad_weight_ih = torch::mm(grad_pre_hy.t(), input);
    auto grad_weight_hh_m = torch::mm(grad_pre_hy.t(), state);

    auto grad_input = torch::mm(grad_pre_hy, weight_ih);
    auto grad_state = torch::mm(grad_pre_hy, weight_hh_m);

    return {grad_input, grad_state, grad_weight_ih, grad_weight_hh_m, grad_weight_hh_n, grad_bias};
}

std::vector<torch::Tensor> mlrlayer_forward(
    torch::Tensor input, // [seq_len, batch_size, input_dim]
    torch::Tensor initial_state, // [batch_size, hidden_size]
    torch::Tensor weight_ih, //[expand_size, input_size]
    torch::Tensor weight_hh_m,
    torch::Tensor weight_hh_n,
    torch::Tensor bias) {

    auto seq_len = input.size(0);
    auto batch_size = input.size(1);
    auto hidden_size = initial_state.size(1);
    auto expand_size = weight_ih.size(0);

    torch::Tensor outputs = torch::empty(
        {seq_len, batch_size, hidden_size}, 
        torch::dtype(input.dtype()).device(input.device()));
    torch::Tensor pre_hys = torch::empty(
        {seq_len, batch_size, expand_size},
        torch::dtype(input.dtype()).device(input.device()));
    torch::Tensor hys = torch::empty(
        {seq_len, batch_size, expand_size},
        torch::dtype(input.dtype()).device(input.device()));

    torch::Tensor state = initial_state;
    for (int t = 0; t < seq_len; ++t) {
        torch::Tensor current_input = input.select(0, t);
        auto result = mlr_forward(current_input, state, weight_ih, weight_hh_m, weight_hh_n, bias);
        outputs.select(0, t).copy_(result[0]);
        pre_hys.select(0, t).copy_(result[1]);
        hys.select(0, t).copy_(result[2]);
    }

    return {outputs, state, pre_hys, hys};
}

std::vector<torch::Tensor> mlrlayer_backward(
    torch::Tensor grad_outputs, // [seq_len, batch_size, hidden_size]
    torch::Tensor input,
    torch::Tensor initial_state,
    torch::Tensor weight_ih,
    torch::Tensor weight_hh_m,
    torch::Tensor weight_hh_n,
    torch::Tensor bias,
    torch::Tensor outputs,
    torch::Tensor pre_hys,
    torch::Tensor hys) {

    auto seq_len = input.size(0);

    torch::Tensor grad_input = torch::zeros_like(input);
    torch::Tensor grad_state = torch::zeros_like(initial_state);
    torch::Tensor grad_weight_ih = torch::zeros_like(weight_ih);
    torch::Tensor grad_weight_hh_m = torch::zeros_like(weight_hh_m);
    torch::Tensor grad_weight_hh_n = torch::zeros_like(weight_hh_n);
    torch::Tensor grad_bias = torch::zeros_like(bias);

    for (int t = seq_len - 1; t >= 0; --t) {
        auto current_input = input.select(0, t);
        auto current_output = outputs.select(0, t);
        auto current_pre_hy = pre_hys.select(0, t);
        auto current_hy = hys.select(0, t);

        torch::Tensor current_grad_output = grad_outputs.select(0, t) + grad_state;

        torch::Tensor current_state;
        if (t == 0) {
            current_state = initial_state;
        } else {
            current_state = outputs.select(0, t-1);
        }

        auto result = mlr_backward(
            current_grad_output, current_input, current_state, weight_ih, weight_hh_m, weight_hh_n, bias, current_output, current_pre_hy, current_hy);

        grad_input.select(0, t).copy_(result[0]);
        grad_state = result[1]; // Update grad_state for the next iteration
        grad_weight_ih.add_(result[2]);
        grad_weight_hh_m.add_(result[3]);
        grad_weight_hh_n.add_(result[4]);
        grad_bias.add_(result[5]);
    }

    return {grad_input, grad_state, grad_weight_ih, grad_weight_hh_m, grad_weight_hh_n, grad_bias};
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("forward", &mlr_forward, "MLR forward");
    m.def("backward", &mlr_backward, "MLR backward");
    m.def("time_forward", &mlrlayer_forward, "MLR forward over time");
    m.def("time_backward", &mlrlayer_backward, "MLR backward over time");
}