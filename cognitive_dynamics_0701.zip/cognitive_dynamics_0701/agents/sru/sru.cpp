#include <torch/extension.h>
#include <vector>
#include <iostream>

std::vector<torch::Tensor> sru_forward(
    torch::Tensor input,             // [batch, input_size]
    torch::Tensor state,             // [batch, hidden_size]
    torch::Tensor weight,            // [hidden_size, hidden_size, input_size]
    torch::Tensor bias               // [hidden_size, input_size]
) {
    auto batch_size = input.size(0);
    auto input_size = input.size(1);
    auto hidden_size = state.size(1);

    auto trial_weight = (weight.unsqueeze(0) * input.view({batch_size, 1, 1, input_size})).sum(-1); // [batch, hidden_size, hidden_size]
    auto trial_bias = (bias.unsqueeze(0) * input.view({batch_size, 1, input_size})).sum(-1); // [batch, hidden_size]

    auto rec_temp = (trial_weight * state.unsqueeze(1)).sum(-1); // [batch, hidden_size]
    auto hy = state + rec_temp + trial_bias;

    return {hy};
}

std::vector<torch::Tensor> sru_backward(
    torch::Tensor grad_hy,           // [batch, hidden_size]
    torch::Tensor input,
    torch::Tensor state,
    torch::Tensor weight,
    torch::Tensor bias
) {
    // 1. Compute gradient w.r.t. trial_bias
    auto grad_trial_bias = grad_hy; // This is a simplification; it might not be directly equal.

    // 2. Compute gradient w.r.t. trial_weight
    auto grad_trial_weight = torch::zeros_like(weight); // This needs to be filled in.

    // 3. Using the above gradients, compute gradient w.r.t. weight and bias
    auto grad_weight = torch::zeros_like(weight); // This needs to be filled in.
    auto grad_bias = torch::zeros_like(bias); // This needs to be filled in.

    // 4. Compute gradient w.r.t. input and state
    auto grad_input = torch::zeros_like(input); // This needs to be filled in.
    auto grad_state = torch::zeros_like(state); // This needs to be filled in.

    return {grad_input, grad_state, grad_weight, grad_bias};
}