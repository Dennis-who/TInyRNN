import os
import kubernetes as k8s
import time
import subprocess
import webbrowser
from kubernetes.stream import stream
from kubernetes.client.rest import ApiException
import re

# Load Kubernetes config
namespace = 'mattarlab-rnn'
ipod_name = "ipod"
k8s.config.load_kube_config()
core_v1 = k8s.client.CoreV1Api()

def set_path():
    os.chdir(os.path.expanduser("~/.kube"))

def delete_ipod():
    print("CMD: kubectl delete pod ",ipod_name)
    try:
        core_v1.delete_namespaced_pod(ipod_name, namespace)
    except k8s.client.exceptions.ApiException as e:
        print(f"Error deleting pod: {e}")
    time.sleep(5)

# Step 3: Create pod from yaml
def create_ipod():
    print("CMD: kubectl create -f",ipod_name+".yaml")
    while True:
        try:
            pod_data = k8s.utils.create_from_yaml(k8s.client.ApiClient(), ipod_name+".yaml")
            break
        except ApiException as e:
            print(f"Error creating pod: {e}")

# check the status of the pod
def check_ipod_status():
    sleep_time = 10
    while True:
        try:
            pod_status = core_v1.read_namespaced_pod_status(ipod_name, namespace).status.phase
            print(f"Current status of ipod: {pod_status}")
            if pod_status == "Running":
                break
        except ApiException as e:
            print(f"Error reading pod status: {e}")
        print(f"Sleeping for {sleep_time} seconds...")
        time.sleep(sleep_time)
        sleep_time *= 2

def exec_ipod(command):
    resp = stream(core_v1.connect_get_namespaced_pod_exec, ipod_name, namespace,
                  command=command,
                  stderr=True, stdin=False,
                  stdout=True, tty=False)
    return resp

# Step 4: Execute command in the pod & Fetch logs
def run_jupyter():
    while True:
        try:
            print("CMD: kubectl exec ",ipod_name," -- /volume/remote_commands.sh")
            resp = exec_ipod(["/volume/remote_commands.sh"])
            break
        except Exception as e:
            print(f"Error executing command in pod: {e}")
            time.sleep(10)

def get_jupyter_links():
    global link, port
    while True:
        try:
            print("CMD: kubectl exec ",ipod_name," -- cat /tmp/jupyter_output.log")
            resp = exec_ipod(["cat", "/tmp/jupyter_output.log"])
            if 'http://' in resp:
                break
            print(f"Jupyter Notebook not ready yet, waiting 10 seconds...")
            time.sleep(10)
        except Exception as e:
            print(f"Error fetching logs from pod: {e}")
            time.sleep(10)

    # Step 5 & 6:  extract link and port
    match = re.search(r"http://127\.0\.0\.1:\d+/\?token=\w+", resp)
    link = match.group()
    port = link.split(":")[-1].split("/")[0]
    print(f"Found Jupyter Notebook URL: {link}")
    print(f"Port: {port}")

# Step 7: Port forwarding
def port_forward():
    port_forward_command = f"kubectl port-forward {ipod_name} {port}:{port}"
    print("CMD: ",port_forward_command)
    powershell_command = f'Start-Process powershell -ArgumentList "-NoExit", "{port_forward_command}"'
    subprocess.Popen(["powershell", "-Command", powershell_command])
    time.sleep(3)

# Step 8: Open Chrome with the link
def open_chrome():
    print(f"Opening Chrome with URL: {link}")
    webbrowser.open(link)

set_path()
delete_ipod()
create_ipod()
check_ipod_status()
run_jupyter()
get_jupyter_links()
port_forward()
open_chrome()

