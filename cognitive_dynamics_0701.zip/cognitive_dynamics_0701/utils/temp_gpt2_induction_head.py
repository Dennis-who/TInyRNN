import numpy as np
import joblib
import matplotlib.pyplot as plt

result_dict = joblib.load('induction_head_all_scores.pkl')
crp_mapping = np.load(
    r'C:\Users\lijia\Documents\WeChat Files\WeChat Files\lijianhet\FileStorage\File\2023-09\tcm_crp.npy')  # 101, 101, 17
# crp_mapping = np.load(r'C:\Users\lijia\Documents\WeChat Files\WeChat Files\lijianhet\FileStorage\File\2023-10\tcm_crp_avg.npy') # 101, 101, 11
crp_mapping_sem = np.load(
    r'C:\Users\lijia\Documents\WeChat Files\WeChat Files\lijianhet\FileStorage\File\2023-10\tcm_crp_sem.npy')  # 101, 101, 11
crp_params = np.load(
    r'C:\Users\lijia\Documents\WeChat Files\WeChat Files\lijianhet\FileStorage\File\2023-09\tcm_crp_params.npy')  # 2, 101, 101
crp_rg = np.arange(-8, 9)  # the range for CRP calculation
# crp_rg = np.arange(-5,6) # the range for new CRP calculation
select_rg = 5


def crp_func(beta1, beta2, select_rg=5, sem=False):  # normalized CRP
    idx_beta1 = np.argmin(np.abs(crp_params[0] - beta1), axis=0)[0]
    idx_beta2 = np.argmin(np.abs(crp_params[1] - beta2), axis=1)[0]
    select_idx = (crp_rg >= -select_rg) & (crp_rg <= select_rg)
    crp = crp_mapping[idx_beta1, idx_beta2, select_idx]
    crp /= crp.sum()
    if sem:
        crp_sem = crp_mapping_sem[idx_beta1, idx_beta2, select_idx]
        crp_sem /= crp.sum()
        return crp, crp_sem
    return crp


# from scipy.spatial.distance import jensenshannon as jsd # jsd not working here

from agents.CogAgentTrainer import _trans_UC


def pr_to_logits(pr, new_max, new_std):
    logits = np.log(pr + 1e-15)
    ori_max, ori_std = logits.max(), logits.std()
    logits = (logits - ori_max) / (ori_std + 1e-15)
    logits = logits * new_std + new_max
    return logits


def tcm_head_MSE(params, head_patt):
    tcm_beta1, tcm_beta2 = params
    tcm_patt = crp_func(tcm_beta1, tcm_beta2, select_rg)
    assert len(tcm_patt) == len(head_patt)

    tcm_patt_logits = pr_to_logits(tcm_patt, head_patt.max(), head_patt.std())

    # weight = np.arange(1,select_rg+1)
    # weight = np.concatenate((weight, [select_rg+1], weight[::-1]))
    # weight = weight / weight.sum() * len(head_patt)
    # weight = np.array([
    #     0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0,
    # ])
    weight = np.ones_like(head_patt)
    return np.mean((tcm_patt_logits - head_patt)**2 * weight / np.var(head_patt))
    # return np.mean(np.abs(tcm_patt_logits - head_patt) * weight / np.std(head_patt))


# def fit_tcm_head(head_patt, repeats = 100, verbose = False):
#     method = 'Nelder-Mead'
#     calculates_gradient = False
#     import scipy.optimize as op
#     param_ranges = ['unit', 'unit', 'pos']
#     # fit_func will take transformed parameters suitable for op.minimize
#     fit_func = lambda params: tcm_head_MSE(_trans_UC(params, param_ranges), head_patt)
#
#     fits = []
#     for i in range(repeats): # Perform fitting.
#         init_params = np.random.normal(0, 3., 3)
#         fits.append(op.minimize(fit_func, init_params, jac = calculates_gradient,
#                                 method = method, options = {'disp': verbose}))
#
#     fit = fits[np.argmin([f['fun'] for f in fits])]  # Select best fit out of repeats.
#
#     head_fit = {
#         'MSE' : fit['fun'],
#         'params': _trans_UC(fit['x'], param_ranges) # Transform parameters back to constrained space
#    }
#
#     return head_fit

def fit_tcm_head(head_patt, return_n_fit=1):
    MSE_array = np.zeros((crp_mapping.shape[0], crp_mapping.shape[1]))
    for beta1_idx in range(crp_mapping.shape[0]):
        for beta2_idx in range(crp_mapping.shape[1]):
            params = [crp_params[0, beta1_idx, 0], crp_params[1, 0, beta2_idx]]
            MSE = tcm_head_MSE(params, head_patt)
            MSE_array[beta1_idx, beta2_idx] = MSE

    if return_n_fit == 1:
        beta1_idx, beta2_idx = np.unravel_index(np.argmin(MSE_array), MSE_array.shape)
        tcm_beta1, tcm_beta2 = crp_params[0, beta1_idx, 0], crp_params[1, 0, beta2_idx]
        head_fit = {
            'MSE': MSE_array[beta1_idx, beta2_idx],
            'params': [tcm_beta1, tcm_beta2],
        }
        return head_fit
    else:
        flattened_indices = np.argsort(MSE_array, axis=None)[:return_n_fit]
        # Convert the flattened indices to 2D indices
        indices_2d = np.unravel_index(flattened_indices, MSE_array.shape)
        smallest_elements = MSE_array.flatten()[flattened_indices]
        head_fits = []
        for i in range(return_n_fit):
            beta1_idx, beta2_idx = indices_2d[0][i], indices_2d[1][i]
            tcm_beta1, tcm_beta2 = crp_params[0, beta1_idx, 0], crp_params[1, 0, beta2_idx]
            head_fit = {
                'MSE': MSE_array[beta1_idx, beta2_idx],
                'params': [tcm_beta1, tcm_beta2],
            }
            head_fits.append(head_fit)
        return head_fits


# print(crp_func(0.5, 0.334, select_rg))
# plt.plot(np.arange(-5,6), crp_func(0.5, 0.334))
# plt.show()

# result_dict = {
#     'head_scores': head_scores, # (n_layer=12, n_head=12)
#     'sorted_head_scores': sorted_head_scores, # (n_layer=12, n_head=12)
#     'CRP_scores': CRP_scores, # (n_layer=12, n_head=12, n_lag=16)
#     'sorted_CRP_scores': sorted_CRP_scores, # (n_layer=12, n_head=12, n_lag=16)
#     'copying_score': utils.to_numpy(full_OV_copying_score), # (n_layer=12, n_head=12)
#     'sorted_copying_score': sorted_copying_score, # (n_layer=12, n_head=12)
#     'labels': labels, # (n_layer=12, n_head=12)
#     'sorted_labels': sorted_labels, # (n_layer=12, n_head=12)
#     'sort_ind': sort_ind, # (n_layer=12, n_head=12)
# }
max_lag = 8
ind = np.arange(-max_lag, max_lag)  # the range for gpt output
gpt_rg = (-select_rg <= ind) & (ind <= select_rg)
head_scores, CRP_scores, copying_score, labels, CRP_scores_sem = \
    result_dict['head_scores'], result_dict['CRP_scores'], result_dict['copying_score'], result_dict['labels'], \
    result_dict['CRP_scores_sem']
sorted_head_scores, sorted_CRP_scores, sorted_copying_score, sorted_labels, sort_ind, sorted_CRP_scores_sem = \
    result_dict['sorted_head_scores'], result_dict['sorted_CRP_scores'], result_dict['sorted_copying_score'], \
    result_dict['sorted_labels'], result_dict['sort_ind'], result_dict['sorted_CRP_scores_sem']

tcm_patt_logits_collection = np.zeros((12, 12, 2 * select_rg + 1))  # (n_layer=12, n_head=12, n_lag=11)
MSE_collection = np.zeros((12, 12))
for L in range(12):
    plt.figure(figsize=(4, 4))
    plt.plot(sorted_head_scores[L], label='original', marker="o")
    plt.legend()
    plt.xticks(np.arange(12), sorted_labels[L], rotation=90)
    plt.ylabel('Induction head matching score')
    ax = plt.gca()
    ax.set_ylim([0, 1])
    ax2 = ax.twinx()
    ax2.plot(sorted_copying_score[L], color="red", marker="x")
    ax2.plot([0] * 12, linestyle='--', color="red")
    ax2.set_ylabel("Copying score", color="red", fontsize=14)
    ax2.set_ylim([-1, 1])
    plt.show()

    plt.figure(figsize=(12, 9))
    for H in range(12):
        plt.subplot(3, 4, H + 1)
        head_patt = sorted_CRP_scores[L, H][gpt_rg]
        plt.plot(np.arange(-select_rg, select_rg + 1), head_patt, marker="o", markersize=3, color='k', label='Head')
        plt.errorbar(np.arange(-select_rg, select_rg + 1), head_patt, yerr=sorted_CRP_scores_sem[L, H][gpt_rg],
                     color='k', alpha=0.6)
        plt.vlines(0, head_patt.min(), head_patt.max(), color='k', linestyles='--')

        head_fits = [fit_tcm_head(head_patt, return_n_fit=1)]
        for fit_i, head_fit in enumerate(head_fits):
            tcm_beta1, tcm_beta2 = head_fit['params']
            print(L, H, head_fit['params'], head_fit['MSE'])
            MSE_collection[L, H] = head_fit['MSE']

            tcm_patt = crp_func(tcm_beta1, tcm_beta2, select_rg)

            # tcm_patt,tcm_patt_sem = crp_func(tcm_beta1, tcm_beta2, select_rg, sem=True)
            tcm_patt_logits = pr_to_logits(tcm_patt,head_patt.max(), head_patt.std())
            # tcm_patt_logits_upper = pr_to_logits(tcm_patt + tcm_patt_sem, head_patt.max(), head_patt.std())
            # tcm_patt_logits_lower = pr_to_logits(tcm_patt - tcm_patt_sem, head_patt.max(), head_patt.std())
            tcm_patt_logits_collection[L, H] = tcm_patt_logits

            if fit_i == 0:
                title = sorted_labels[L][H] + f'\nMSE={head_fit["MSE"]:.3f} beta1={tcm_beta1:.2f} beta2={tcm_beta2:.2f}'
                plt.title(title)
                label = 'TCM fit'
            else:
                label = None
            plt.plot(np.arange(-select_rg, select_rg + 1), tcm_patt_logits, marker="x", markersize=3, color='r',
                     alpha=0.3,
                     label=label)
            # plt.fill_between(np.arange(-select_rg,select_rg+1), tcm_patt_logits_lower, tcm_patt_logits_upper, color='r', alpha=0.7)
            # print(fit_i,tcm_beta1, tcm_beta2, 'upper',tcm_patt_logits_upper, 'lower',tcm_patt_logits_lower)
        plt.legend()
        if H >= 8:
            plt.xlabel('Lag')
        if H % 4 == 0:
            plt.ylabel('Attention scores')
            # plt.ylabel('Transformed Pr.')
        # plt.tight_layout()
    plt.show()

import joblib

joblib.dump({
    'tcm_patt_logits_collection': tcm_patt_logits_collection,
    'MSE_collection': MSE_collection,
}, 'tcm_patt_logits_collection.pkl')
color = sorted_copying_score.flatten() > 0  # blue for +, red for -
color = np.where(color, 'b', 'r')
plt.figure(figsize=(2, 2))
fig, axs = plt.subplots(2, 1, sharex=True, tight_layout=True)
axs[0].scatter(MSE_collection.flatten(), sorted_head_scores.flatten(), c=color, s=2)
# label one blue and one red point
blue_idx = np.where(color == 'b')[0][0]
axs[0].scatter([MSE_collection.flatten()[blue_idx]], [sorted_head_scores.flatten()[blue_idx]], c='b', s=2, label='Copying score>0')
red_idx = np.where(color == 'r')[0][0]
axs[0].scatter([MSE_collection.flatten()[red_idx]], [sorted_head_scores.flatten()[red_idx]], c='r', s=2, label='Copying score<0')
axs[0].legend()
axs[0].set_ylabel('Induction head matching score')
axs[1].hist(MSE_collection.flatten(), bins=25)
axs[1].set_xlabel('TCM distance (MSE)')
axs[1].set_ylabel('Count')
plt.show()