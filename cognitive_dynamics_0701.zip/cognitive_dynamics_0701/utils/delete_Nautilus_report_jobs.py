import tkinter as tk

def truncate_after(line, after_str="prop", append_str="prop.x"):
    # Split the line at "prop.x" and keep the part before it
    parts = line.split(after_str)
    truncated_line = parts[0] + append_str if len(parts) > 1 else line
    return truncated_line



def process_input():
    input_text = text_input.get("1.0", "end-1c")
    lines = input_text.split("\n")
    output_text.delete("1.0", "end")
    output_text2.delete("1.0", "end")
    for line in lines:
        parts = line.split("\t")
        if len(parts) > 1:
            pod_name = parts[0].split("/")[1]
            pod_name = truncate_after(pod_name)
            command = f"kubectl delete -f {pod_name}.yaml"
            output_text.insert("end", command + "\n")
            output_text2.insert("end", command.replace("delete", "apply") + "\n")

def copy_to_clipboard(widget):
    root.clipboard_clear()
    root.clipboard_append(widget.get("1.0", "end-1c"))

root = tk.Tk()
root.title("Kubernetes Pod Command Generator")

text_input = tk.Text(root, height=10)
text_input.pack()

process_button = tk.Button(root, text="Process", command=process_input)
process_button.pack()
output_text = tk.Text(root, height=10)
output_text.pack()

copy_button1 = tk.Button(root, text="Copy Commands", command=lambda: copy_to_clipboard(output_text))
copy_button1.pack()

output_text2 = tk.Text(root, height=10)
output_text2.pack()

copy_button2 = tk.Button(root, text="Copy Commands", command=lambda: copy_to_clipboard(output_text2))
copy_button2.pack()

root.mainloop()
