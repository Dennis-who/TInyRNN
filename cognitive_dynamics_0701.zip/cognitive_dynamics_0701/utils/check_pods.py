import subprocess
import pandas as pd
import os

namespace = 'mattarlab-rnn'
# os.chdir(r'D:\OneDrive\Documents\git_repo\cognitive_dynamics\files\kube')
def get_kubectl_pods_as_dataframe(namespace='mattarlab-rnn'):
    cmd = ["kubectl", "get", "pods", "-n", namespace, "-o", "wide"]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    lines = result.stdout.strip().split('\n')
    headers = lines[0].split()[:7] # NAME, READY, STATUS, RESTARTS, AGE, IP, NODE
    data = [line.split()[:7] for line in lines[1:]]
    df = pd.DataFrame(data, columns=headers)
    return df


def count_kubectl_pods(status_list=None, pod_df=None, namespace='mattarlab-rnn'):
    if status_list is None:
        # consider these statuses taking resources
        status_list = ['Running', 'ContainerCreating', # is taking resources
                       'CrashLoopBackOff','ImagePullBackOff','ErrImagePull','ImageInspectError','CreateContainerConfigError','CreateContainerError', # is waiting
                       ]
    if pod_df is None:
        pod_df = get_kubectl_pods_as_dataframe(namespace)
    return sum(pod_df['STATUS'].isin(status_list))

if __name__ == '__main__':
    pod_df = get_kubectl_pods_as_dataframe(namespace)
    with pd.option_context('display.max_rows', None, 'display.max_columns', None, 'display.expand_frame_repr', False):
        print(pod_df)

    pod_groups = {}
    for status, group in pod_df.groupby('STATUS'):
        pod_groups[status] = list(group['NAME'])
        print(f"\n========{len(pod_groups[status])} Pods in '{status}' status:==========")
        for pod_name in pod_groups[status]:
            print(pod_name)

        L = []
        print("Delete commands:")
        for pod_name in pod_groups[status]:
            yaml_name = '-'.join(pod_name.split('-')[:-1])
            if yaml_name not in L:
                L.append(yaml_name)
                print(f"kubectl delete -f {yaml_name}.yaml")

        print("Apply commands:")
        for yaml_name in L:
            print(f"kubectl apply -f {yaml_name}.yaml")
