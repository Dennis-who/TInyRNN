import tkinter as tk
from tkinter import ttk, filedialog

import subprocess
import os
def execute_command(cmd):
    """Execute a command and return the stdout and stderr."""
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, text=True)
    return result.stdout + '\n' + result.stderr

def get_job_count_by_state():
    # Placeholder; replace with actual function
    return 10


def get_pod_count_by_state():
    # Placeholder; replace with actual function
    return 5


def display_info(frame):
    job_count = get_job_count_by_state()
    pod_count = get_pod_count_by_state()

    tk.Label(frame, text=f"Number of jobs: {job_count}").pack(pady=10)
    tk.Label(frame, text=f"Number of pods: {pod_count}").pack(pady=10)

def create_buttons(frame):
    btn_list = ttk.Button(frame, text="List jobs", command=list_jobs)
    btn_delete = ttk.Button(frame, text="Delete jobs", command=delete_jobs)
    btn_submit = ttk.Button(frame, text="Submit jobs", command=submit_jobs)

    btn_list.pack(pady=10)
    btn_delete.pack(pady=10)
    btn_submit.pack(pady=10)

def list_jobs():
    # Create a new window
    window = tk.Toplevel()
    window.title("List of Jobs")
    window.geometry("500x400")

    # Get list of jobs
    jobs_output = execute_command('kubectl get jobs')

    # Display jobs in a Text widget with a scrollbar
    text_widget = tk.Text(window, wrap=tk.WORD, yscrollcommand=True)
    text_widget.insert(tk.END, jobs_output)
    text_widget.pack(expand=True, fill=tk.BOTH)

    scrollbar = ttk.Scrollbar(window, command=text_widget.yview)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    text_widget.config(yscrollcommand=scrollbar.set)

def delete_jobs():
    window = tk.Toplevel()
    window.title("Delete Jobs")
    window.geometry("500x400")

    # Get list of jobs
    jobs_output = execute_command('kubectl get jobs').splitlines()
    selected_jobs = tk.StringVar(value=jobs_output)  # Store selected jobs

    # Create Checkbuttons for each job
    for job in jobs_output:
        ttk.Checkbutton(window, text=job, variable=selected_jobs, onvalue=job, offvalue="").pack(anchor=tk.W)

    # Button to confirm deletion
    ttk.Button(window, text="Delete Selected", command=lambda: confirm_delete(selected_jobs.get())).pack(pady=20)

def confirm_delete(selected):
    jobs_list = selected.split()
    for job in jobs_list:
        # Here, you'd run the command to delete the job
        # For now, I'm just printing the job name
        print(f"Deleting job {job}")


def submit_jobs():
    window = tk.Toplevel()
    window.title("Submit Jobs")
    window.geometry("500x400")

    # Let user select .txt file or multiple .yaml files
    ttk.Button(window, text="Select .txt file", command=lambda: select_and_submit_txt(window)).pack(pady=10)
    ttk.Button(window, text="Select .yaml files", command=lambda: select_and_submit_yaml(window)).pack(pady=10)

def select_and_submit_txt(window):
    file_path = filedialog.askopenfilename(title="Select a .txt file", filetypes=[("Text files", "*.txt")])
    if file_path:
        with open(file_path, 'r') as f:
            jobs = f.readlines()
        # Display jobs and provide a button to submit
        display_and_submit_jobs(window, jobs)

def select_and_submit_yaml(window):
    files = filedialog.askopenfilenames(title="Select .yaml files", filetypes=[("YAML files", "*.yaml")])
    if files:
        jobs = [os.path.basename(f).replace('.yaml', '') for f in files]
        # Display jobs and provide a button to submit
        display_and_submit_jobs(window, jobs)

def display_and_submit_jobs(window, jobs):
    for job in jobs:
        ttk.Label(window, text=job).pack(anchor=tk.W)
    ttk.Button(window, text="Submit", command=lambda: actual_submit(jobs)).pack(pady=20)

def actual_submit(jobs):
    for job in jobs:
        # Here, you'd run the command to submit the job
        # For now, I'm just printing the job name
        print(f"Submitting job {job}")


def create_main_window():
    root = tk.Tk()
    root.title("Kubernetes Job Manager")
    root.geometry("400x400")

    main_frame = ttk.Frame(root)
    main_frame.pack(pady=20)

    display_info(main_frame)
    create_buttons(main_frame)

    root.mainloop()


if __name__ == "__main__":
    create_main_window()