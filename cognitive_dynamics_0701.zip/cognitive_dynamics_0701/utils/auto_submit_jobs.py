import os
import datetime
import subprocess
import tkinter as tk
import pandas as pd
from tkinter import filedialog
KUBE_DIR = r'D:\OneDrive\Documents\git_repo\cognitive_dynamics\files\kube'
MIN_SLEEP_TIME = 60
MAX_SLEEP_TIME = 3600
SOFT_QUOTA_COUNT = 105 #105
NAMESPACE = 'mattarlab-rnn'
SKIP_NAMEs = ['mlr']

def get_kubectl_pods_as_dataframe(namespace='mattarlab-rnn'):
    cmd = ["kubectl", "get", "pods", "-n", namespace, "-o", "wide"]
    result = execute_command(cmd, return_as_str=False)
    lines = result.stdout.strip().split('\n')
    headers = lines[0].split()[:7] # NAME, READY, STATUS, RESTARTS, AGE, IP, NODE
    data = [line.split()[:7] for line in lines[1:]]
    df = pd.DataFrame(data, columns=headers)
    return df


def count_kubectl_pods(status_list=None, pod_df=None, namespace='mattarlab-rnn'):
    if status_list is None:
        # consider these statuses taking resources
        status_list = ['Running', 'ContainerCreating', # is taking resources
                       'CrashLoopBackOff','ImagePullBackOff','ErrImagePull','ImageInspectError','CreateContainerConfigError','CreateContainerError', # is waiting
                       ]
    if pod_df is None:
        pod_df = get_kubectl_pods_as_dataframe(namespace)
    if len(pod_df) == 0:
        return 0
    return sum(pod_df['STATUS'].isin(status_list))

def select_file_window():
    """Open a window to select a file."""
    root = tk.Tk()
    root.withdraw()  # This hides the root window
    file_path = filedialog.askopenfilename(title="Select a file with one yaml name in each line", filetypes=[("Text files", "*.txt")])
    root.destroy()
    if not file_path:
        return None
    file_path = file_path.replace("/", "\\")
    print(f"Selected file: {file_path}")
    return file_path


def execute_command(cmd, timeout_duration=30, timeout_sleep_time=180, return_as_str=True):
    """Execute a command and return the stdout and stderr."""

    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, text=True, timeout=timeout_duration)
        result_str = result.stdout + '\n' + result.stderr
        if 'timeout' in result_str.lower():
            raise subprocess.TimeoutExpired(cmd, timeout_duration)
        if return_as_str:
            return result_str
        else:
            return result
    except subprocess.TimeoutExpired:
        print(f"======Timeout expired for command: {cmd}======")
        print("======Sleeping for " + str(timeout_sleep_time) + " seconds. Then will check again.======")
        os.system(f'powershell -Command "Start-Sleep -s {timeout_sleep_time}"')
        return execute_command(cmd, timeout_duration=timeout_duration, timeout_sleep_time=timeout_sleep_time*2, return_as_str=return_as_str)



def clear_completed_resources(filter_str="y"):
    """Clear successfully completed jobs and pods."""
    # Construct kubectl commands based on filter
    get_pods_cmd = 'kubectl get pods --field-selector=status.phase==Succeeded -o custom-columns=:.metadata.name'
    get_jobs_cmd = 'kubectl get jobs --field-selector=status.successful==1 -o custom-columns=:.metadata.name'
    get_ipods_cmd = "kubectl get pods -o custom-columns=NAME:.metadata.name,REASON:.status.reason | Where-Object { $_ -like '*DeadlineExceeded*' }"

    if filter_str.lower() not in ['y','n']:
        get_pods_cmd += f' | Select-String -Pattern {filter_str}'
        get_jobs_cmd += f' | Select-String -Pattern {filter_str}'
        get_ipods_cmd += f' | Select-String -Pattern {filter_str}'

    #using powershell commands
    get_pods_cmd = f'powershell -Command "{get_pods_cmd}"'
    get_jobs_cmd = f'powershell -Command "{get_jobs_cmd}"'
    get_ipods_cmd = f'powershell -Command "{get_ipods_cmd}"'

    # Get list of jobs to be deleted
    jobs_to_delete = execute_command(get_jobs_cmd).splitlines()
    # delete job first; if job is deleted, pod will be deleted automatically
    n_job = 0
    for job in jobs_to_delete:
        if len(job) == 0:
            continue
        print(f"kubectl delete job {job}")
        os.system(f"kubectl delete job {job}")
        n_job += 1
    print(f"======Deleted {n_job} jobs.======")

    # Get list of pods to be deleted
    pods_to_delete = execute_command(get_pods_cmd).splitlines() + execute_command(get_ipods_cmd).splitlines()
    n_pod = 0
    for pod in pods_to_delete:
        if len(pod) == 0:
            continue
        print(f"kubectl delete pod {pod}")
        os.system(f"kubectl delete pod {pod}")
        n_pod += 1
    print(f"======Deleted {n_pod} pods.======")

    # Log deleted resources
    if n_pod + n_job > 0:
        datetime_now = datetime.datetime.now()
        date_now = datetime_now.strftime('%Y%m%d')
        time_now = datetime_now.strftime('%H%M%S')
        datetime_now = datetime_now.strftime('%Y%m%d %H%M%S')
        os.makedirs('deleted_pods_jobs_logs', exist_ok=True)
        with open(f"deleted_pods_jobs_logs/deleted_pods_jobs_{date_now}.txt", "a+") as log_file:
            log_file.writelines(f"\n======{datetime_now}======\n")
            log_file.write("\n".join(jobs_to_delete+pods_to_delete))

    return max(n_pod, n_job)

def submit_jobs(input_file, filter_str="y"):
    # generate submission result files
    to_submit_file = input_file.replace(".txt", "_to_submit.txt")
    submitted_file = input_file.replace(".txt", "_submitted.txt")
    error_file = input_file.replace(".txt", "_error.txt")
    error_reason_file = input_file.replace(".txt", "_error_reason.txt")

    # whether to start over or continue from where you left off
    if os.path.exists(to_submit_file) or os.path.exists(submitted_file) or os.path.exists(error_file) or os.path.exists(error_reason_file):
        print("======Warning: one or more of the following files already exist:======")
        print(to_submit_file)
        print(submitted_file)
        print(error_file)
        print(error_reason_file)
        print("======Start over from the beginning, or continue from where you left off?======")
        print("1. Start over")
        print("2. Continue from where you left off")
        choice = input("Enter your choice (1/2): ")
        if choice == "1": # forced deleting files
            for file in [to_submit_file, submitted_file, error_file, error_reason_file]:
                if os.path.exists(file):
                    os.remove(file)
            os.system(f'copy {input_file} {to_submit_file}')
    else:
        print(f'copy {input_file} {to_submit_file}')
        os.system(f'copy {input_file} {to_submit_file}')


    with open(to_submit_file, 'r') as f:
        jobs = f.readlines()

    sleep_time = MIN_SLEEP_TIME
    submitted_count = 0
    error_count = 0
    gross_completed_pod_count = 0 # a rough estimate of the number of pods that have completed, maybe different from submitted_count
    exceed_quota_choice = None
    pod_df = get_kubectl_pods_as_dataframe(NAMESPACE)
    estimated_current_pod_count = count_kubectl_pods(pod_df=pod_df, namespace=NAMESPACE) # these pods taking resources
    skip_status = False
    while True: # keep submitting jobs until all jobs are submitted or exit manually by user
        if len(jobs) == 0:
            break
        print('Current estimated pod count: ', estimated_current_pod_count,
              'Soft quota count: ', SOFT_QUOTA_COUNT,
              'gross_completed_pod_count: ', gross_completed_pod_count)

        job = jobs[0].replace('.yaml', '').replace('kubectl apply -f', '').replace('kubectl delete -f', '').strip()
        if 'SKIP' in job:
            print("======Skipping submission due to SKIP.======")
            skip_status = True
            jobs.pop(0)
            continue
        if 'RESUME' in job:
            print("======Resuming submission due to RESUME.======")
            skip_status = False
            jobs.pop(0)
            continue
        if 'PAUSE' in job:
            print("======Pausing submission due to PAUSE.======")
            jobs.pop(0)
            break

        if skip_status:
            jobs.pop(0)
            continue

        if any([skip_name in job for skip_name in SKIP_NAMEs]):
            print("======Skipping", job, "due to skip names.======")
            jobs.pop(0)
            continue

        if estimated_current_pod_count <= SOFT_QUOTA_COUNT:
            job_cmd = 'kubectl apply -f ' + job + '.yaml'
            print(job_cmd)
            output = execute_command(job_cmd)  # Execute the kubectl command and capture output
        else:
            output = "exceeded quota of " + str(SOFT_QUOTA_COUNT)
        print(output)

        if "created" in output:
            # Job submitted successfully
            with open(submitted_file, 'a') as f:
                f.writelines(job+'\n')
            # delete job from jobs
            jobs.pop(0)
            submitted_count += 1
            estimated_current_pod_count += 1

            # Update the _to_submit file with remaining jobs
            with open(to_submit_file, 'w') as f:
                f.writelines(jobs)

            sleep_time = MIN_SLEEP_TIME

        elif "exceeded quota" in output:
            print("======Quota exceeded! ======")
            if exceed_quota_choice is None:
                print("Choose an option:")
                print("1. Exit")
                print("2. Wait for jobs to complete and then continue submitting")
                exceed_quota_choice = input("Enter your choice (1/2): ")
                if exceed_quota_choice not in ["1", "2"]:
                    print("Invalid choice. Exiting.")
                    break
            if exceed_quota_choice == "1":
                break
            elif exceed_quota_choice == "2":
                print("======Sleeping for " + str(sleep_time) + " seconds. Then will check again.======")
                os.system(f'powershell -Command "Start-Sleep -s {sleep_time}"')
                sleep_time *= 2
                if sleep_time > MAX_SLEEP_TIME:
                    sleep_time = MAX_SLEEP_TIME
                pod_df = get_kubectl_pods_as_dataframe(NAMESPACE)
                just_completed_pod_count = count_kubectl_pods(status_list=['Completed'],
                                                        pod_df=pod_df, namespace=NAMESPACE)
                if just_completed_pod_count > 0:
                    gross_completed_pod_count += just_completed_pod_count
                    clear_completed_resources(filter_str)
                estimated_current_pod_count = count_kubectl_pods(pod_df=pod_df, namespace=NAMESPACE) # reset estimated_current_pod_count
        else:
            # Job submission failed for some other reason
            with open(error_file, 'a') as f:
                f.writelines(job+'\n')
            with open(error_reason_file, 'a') as f:
                f.writelines(output) # already contains '\n'
            # delete job from jobs
            jobs.pop(0)
            error_count += 1

            # Update the _to_submit file with remaining jobs
            with open(to_submit_file, 'w') as f:
                f.writelines(jobs)

            sleep_time = MIN_SLEEP_TIME


    # Step 4: Report results
    to_submit_count = len(jobs)
    print(f"======{to_submit_count} jobs remaining to be submitted.======")
    print(f"======Successfully submitted {submitted_count} jobs.======")
    print(f"======Encountered errors with {error_count} jobs.======")

def main():
    os.chdir(KUBE_DIR)

    # Step 1: Get job file input from user
    print("======Select a file with one yaml name in each line======")
    job_file = select_file_window()

    # Step 2: Ask user about clearing completed resources
    filter_str = input("Clear successfully completed jobs and pods? (y for yes; n for no; e for exit; or job name filter string): ")
    if filter_str == "e":
        return
    if filter_str != "n":
        clear_completed_resources(filter_str)

    if job_file is None:
        return
    # Step 3: Submit jobs
    submit_jobs(job_file, filter_str)

if __name__ == "__main__":
    main()