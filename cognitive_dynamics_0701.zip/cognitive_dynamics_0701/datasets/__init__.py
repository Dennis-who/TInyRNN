"""Interface for creating datasets.

Each dataset can be created from a string of dataset name.
"""

from .BaseTwoStepDataset import nn_session
from .dataset_utils import Dataset
