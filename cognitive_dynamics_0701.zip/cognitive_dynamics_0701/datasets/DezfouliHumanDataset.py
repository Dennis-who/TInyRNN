import pandas as pd
import scipy.io
import numpy as np
from .BaseTwoStepDataset import BaseTwoStepDataset, _combine_data_dict
import os
import json

class DezfouliHumanDataset(BaseTwoStepDataset):
    """A dataset class for the bandit task with binary actions and rewards.

    One step task indeed, with states equal to actions.

    Attributes:
         unique_trial_type: How many possible unique trial observations (actions * rewards = 4 combinations)
         behav: Standard format of behavioral data.
         data_path: Where to load the data.
         behav_format: tensor (for RNN) or cog_session (for Cog agents)?
         torch_beahv_input: tensor format of agent's input
         torch_beahv_input_1hot: tensor format of agent's input (one-hot encoding of trial observations)
         torch_beahv_target: tensor format of agent's target output
         cog_sessions: cog_session format of agent's input & target output
         batch_size: How many blocks are there in the current loaded data?
    """
    def __init__(self, data_path=None, behav_data_spec=None, neuro_data_spec=None, verbose=True):
        self.unique_trial_type = 4
        self.sessions = {
            }
        super().__init__(data_path, behav_data_spec, neuro_data_spec, verbose=verbose)


    def _detect_trial_type(self):
        """Detect trial type from behavioral data."""
        behav = self.behav
        behav['trial_type'] = []
        for i in range(len(behav['action'])):
            behav['trial_type'].append(behav['action'][i] * 2 + behav['reward'][i])

    def _load_all_trial_type(self, behav_data_spec):
        np2list = lambda L: [np.array([x]) for x in L]
        self.behav = {
            'action': np2list([0, 0, 1, 1]),
            'stage2': np2list([0, 0, 1, 1]),
            'reward': np2list([0, 1, 0, 1]),
        }
        self._detect_trial_type()

    def data_summary(self):
        """Print a summary of the dataset.
        animal_name: total trial num,
        """
        import pprint
        pp = pprint.PrettyPrinter(depth=4, sort_dicts=False)
        trial_counter = {}
        for diag in self.data['diag'].unique():
            data_diag = self.data[self.data['diag'] == diag]
            print('==Diagnosis: {}'.format(diag))
            for ID in data_diag['ID'].unique():
                print('ID: {}'.format(ID), end=':')
                data_ID = data_diag[data_diag['ID'] == ID]
                for block in data_ID['block'].unique():
                    data_block = data_ID[data_ID['block'] == block].iloc[0]['action']
                    print('{},'.format(len(data_block)), end='')
                    trial_counter[ID] = trial_counter.setdefault(ID, 0) + len(data_block)
                print()
        pp.pprint({k: v for k, v in trial_counter.items()})
        pp.pprint({k: v for k, v in trial_counter.items() if v>1400})
        # pp.pprint({k: v for k, v in sorted(trial_counter.items(), key=lambda item: item[1])})

    def _load_all_data(self):
        data = pd.read_csv(self.data_path / 'for_plos.csv')
        # from subject ID to number
        self.ID2num = ID2num = {key: i for i, (key, item) in enumerate(data.groupby(['ID']))}
        json_path = self.data_path / 'Dezfouli_ID2num.json'
        # save ID2num and check if it is consistent with the saved one
        if os.path.exists(json_path):
            with open(json_path, 'r') as f:
                ID2num_ = json.load(f)
            assert ID2num == ID2num_
        else:
            with open(json_path, 'w') as f:
                json.dump(ID2num, f)
        data['ID'] = data['ID'].apply(lambda x: ID2num[x])

        data = data.groupby(['ID','block']).agg(list).reset_index()
        data.rename(columns={'key':'action'}, inplace=True)
        data['action'] = data['action'].apply(lambda x: [int(y == 'R2') for y in x])
        data['diag'] = data['diag'].apply(lambda x: x[0])
        self.data = data

    def load_data(self, behav_data_spec, neuro_data_spec=None, verbose=True):
        """Load behavioral and neural data.

        The loaded data is stored in self.behav, the standard format of behavioral data.

        Args:
            behav_data_spec: A dictionary of behavioral data specification.
            neuro_data_spec: A dictionary of neural data specification.
                select_bins
         """
        if 'all_trial_type' in behav_data_spec and behav_data_spec['all_trial_type']:
            self._load_all_trial_type(behav_data_spec)
            return

        self._load_all_data()

        if isinstance(behav_data_spec['subject_number'], int):
            behav_data_spec['subject_number'] = [behav_data_spec['subject_number']]
        if behav_data_spec['subject_number'] == 'all':
            subject_list = self.data['ID'].unique()
        else:
            subject_list = behav_data_spec['subject_number']
        if neuro_data_spec is None:
            neuro_data_spec = {}
        self.behav_data_spec = behav_data_spec
        self.neuro_data_spec = neuro_data_spec

        self.behav = behav = {}
        self.neuro = neuro = {}
        for sub in subject_list:
            if verbose: print('====Load subject_number:', sub)
            data_sub = self.data[self.data['ID'] == sub]
            for block in data_sub['block'].unique():
                data_block = data_sub[data_sub['block'] == block].iloc[0]
                behav.setdefault('action', []).append(np.array(data_block['action']))
                behav.setdefault('stage2', []).append(np.array(data_block['action']))
                behav.setdefault('reward', []).append(np.array(data_block['reward']))
                behav.setdefault('sub_id', []).append(sub * np.ones(len(data_block['action'])))
                behav.setdefault('block', []).append(block)

        self._detect_trial_type()
        if verbose: print('Total trial num:', self.total_trial_num)
