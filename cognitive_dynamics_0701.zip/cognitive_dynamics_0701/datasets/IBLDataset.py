import numpy as np
import json
from pathlib import Path
import matplotlib.pyplot as plt

import numpy as np
from .BaseTwoStepDataset import BaseTwoStepDataset, _combine_data_dict, nn_session
import torch

class IBLDataset(object):
    """A dataset class for the IBL task.

    Attributes:
         behav: Standard format of behavioral data.
         data_path: Where to load the data.
         behav_format: tensor (for RNN) or cog_session (for Cog agents)?
         torch_beahv_input: tensor format of agent's input
         torch_beahv_input_1hot: tensor format of agent's input (one-hot encoding of trial observations)
         torch_beahv_target: tensor format of agent's target output
         cog_sessions: cog_session format of agent's input & target output
         batch_size: How many blocks are there in the current loaded data?
    """
    def __init__(self, data_path=None, behav_data_spec=None, neuro_data_spec=None, verbose=True):
        with open(data_path / 'final_animal_eid_dict.json', 'r') as f:
            self.animal_eid_dict = json.load(f)
        # ['IBL-T1', 'IBL-T2', 'IBL-T3', 'IBL-T4', 'NYU-01', 'NYU-02', 'NYU-04', 'NYU-06',
        # 'CSHL_001', 'CSHL_002', 'CSHL_003', 'CSHL_005', 'CSHL_007', 'CSHL_008', 'CSHL_010', 'CSHL_012',
        # 'CSHL_014', 'CSHL_015', 'KS003', 'KS005', 'KS019', 'ZM_1367', 'ZM_1369', 'ZM_1371', 'ZM_1372',
        # 'ZM_1743', 'ZM_1745', 'ZM_1746', 'ibl_witten_04', 'ibl_witten_05', 'ibl_witten_06', 'ibl_witten_07',
        # 'ibl_witten_12', 'ibl_witten_13', 'ibl_witten_14', 'ibl_witten_15', 'ibl_witten_16']
        self.animal_list = self.animal_eid_dict.keys()
        assert data_path is not None
        self.behav = {}
        self.torch_beahv_input = None
        self.torch_beahv_input_1hot = None
        self.torch_beahv_target = None
        self.torch_beahv_mask = None
        self.cog_sessions = None
        self.behav_format = None
        self.data_path = data_path
        if behav_data_spec is not None:
            self.load_data(behav_data_spec, neuro_data_spec, verbose)
        return


    def _detect_trial_type(self):
        """Detect trial type from behavioral data.
        Here the trial type of the current trial is defined as the events between the current action and the next action,
        including the current trial action, reward, and the next trial stimulus.
        The trial type, together with the current logit determines the agent's next action logit.
        """
        behav = self.behav
        behav['trial_type'] = []
        for i in range(len(behav['action'])):
            trial_num = len(behav['action'][i])
            trial_type = np.zeros([trial_num, 3])
            trial_type[:, 0] = behav['action'][i]
            trial_type[:, 1] = behav['reward'][i]
            trial_type[:-1, 2] = behav['stim_diff'][i][1:]
            # mask out invalid trials
            trial_type[-1, :] = -10 # "invalid" trial type because the last trial has no next stimulus
            invalid_trials = np.where(behav['mask'][i] == 0)[0]
            trial_type[invalid_trials, :] = -10 # because no action in this trial and a -1 reward
            # this affect the trial type of the next trial
            behav['trial_type'].append(trial_type)

    def load_data(self, behav_data_spec, neuro_data_spec=None, verbose=True):
        """Load behavioral and neural data.

        Args:
            behav_data_spec: A dictionary of behavioral data specification.
            neuro_data_spec: A dictionary of neural data specification.
                select_bins
         """
        animal_name = behav_data_spec['animal_name']
        behav_data_spec['session_name'] = self.animal_eid_dict[animal_name]
        if neuro_data_spec is None:
            neuro_data_spec = {}
        self.behav_data_spec = behav_data_spec
        self.neuro_data_spec = neuro_data_spec

        self.behav = behav = {}
        self.neuro = neuro = {}
        if verbose: print('====Load behavioral data for animal:', animal_name)
        for sess_name in behav_data_spec['session_name']:
            # if verbose: print('====Load session:', sess_name)
            eid = sess_name
            eid_str = eid.split('Subjects/')[1].replace('/', '-') + '.npz'
            data = np.load(self.data_path / animal_name / eid_str, allow_pickle=True)['arr_0'][()]

            data['stim_left'][np.isnan(data['stim_left'])] = 0
            data['stim_right'][np.isnan(data['stim_right'])] = 0
            data['stim_diff'] = data['stim_right'] - data['stim_left']
            data['rewarded'][data['rewarded'] == -1] = 0
            data['choice'] = remap_choice_vals(data['choice']) # 0: left, 1: right, -1: no choice
            data['mask'] = (data['choice'] != -1) * 1 # 0: no choice, 1: choice
            behav.setdefault('session', []).append(sess_name)
            behav.setdefault('stim_left', []).append(data['stim_left'])
            behav.setdefault('stim_right', []).append(data['stim_right'])
            behav.setdefault('stim_diff', []).append(data['stim_diff'])
            behav.setdefault('reward', []).append(data['rewarded'])
            behav.setdefault('action', []).append(data['choice'])
            behav.setdefault('mask', []).append(data['mask'])

        self._detect_trial_type()
        if verbose: print('Total trial num:', self.total_trial_num, 'Total block num:', self.batch_size)

    def behav_to(self, format_config=None):
        """Transform standard data to specified data format, either tensor or cog_session format.

        Args:
            format_config: A dict specifies how the standard data should be transformed.
                Only the "behav_format" and "one_hot" keys are used.

        Returns:
            The dataset instance itself.
        """
        assert format_config is not None
        self.behav_format = format_config['behav_format']
        if self.behav_format == 'tensor':
            self._behav_to_tensor(format_config)
        elif self.behav_format == 'cog_session':
            self._behav_to_cog_sessions(format_config)
        else:
            raise NotImplementedError
        return self

    @property
    def batch_size(self):
        """How many blocks in total?"""
        return len(self.behav['action'])

    @property
    def total_trial_num(self):
        """How many trials in total?"""
        return sum([len(block) for block in self.behav['action']])


    def get_behav_data(self, batch_indices, format_config=None):
        """Return a subset (a few batches) of loaded data with specified format.

        Args:
            batch_indices: A list or 1d ndarray specifies which batches are extracted.
            format_config: A dict specifies how the standard data should be transformed.
                Mainly "behav_format" and "one_hot" keys.

        Returns:
            A dict contains:
                input, target_output, mask if for the tensor format.
                List of sessions (a session = a block) if for the cog_session format.
        """
        assert isinstance(batch_indices, list) or isinstance(batch_indices, np.ndarray) and len(batch_indices.shape) == 1
        if self.behav_format is None: # the standard format
            behav = {}
            for k, v in self.behav.items():
                behav[k] = [v[idx] for idx in batch_indices]
            return behav
        assert format_config is not None
        assert self.behav_format == format_config['behav_format']
        trial_type = np.array(self.behav['trial_type'])
        if self.behav_format == 'tensor':
            return {'input': self.torch_beahv_input[:,batch_indices],
                    'target': self.torch_beahv_target[:,batch_indices],
                    'mask': self.torch_beahv_mask[:, batch_indices],
                    'trial_type': trial_type[batch_indices],
                    }
        elif self.behav_format == 'cog_session':
            return {'input': [self.cog_sessions[b] for b in batch_indices],
                    'trial_type': trial_type[batch_indices],
                    }
        else:
            raise NotImplementedError

    def _behav_to_tensor(self, format_config):
        """Transform standard behavioral format to tensor format, stored in torch_beahv_* attribute.

        standard format (list of 1d array) -> tensor format (2d array with 0 padding).
        The attributes are:
            torch_beahv_input: tensor format of agent's input
            torch_beahv_input_1hot: tensor format of agent's input (one-hot encoding of trial observations)
            torch_beahv_target: tensor format of agent's target output
            torch_beahv_mask: tensor format of agent's mask (1 for valid trials, 0 for padding trials)

        Args:
            format_config: A dict specifies how the standard data should be transformed.

        """
        if self.torch_beahv_input is not None:
            return
        max_trial_num =np.unique([len(block) for block in self.behav['reward']])
        assert len(max_trial_num) == 1
        max_trial_num = max_trial_num[0]
        act = np.zeros((self.batch_size, max_trial_num, 2))
        rew = np.zeros((self.batch_size, max_trial_num, 1))
        stim = np.zeros((self.batch_size, max_trial_num,2))
        mask = np.zeros((self.batch_size, max_trial_num))
        for b in range(self.batch_size):
            act[b, self.behav['action'][b] == 0, 0] = 1
            act[b, self.behav['action'][b] == 1, 1] = 1
            rew[b, :, 0] = self.behav['reward'][b]
            stim[b, :, 0] = self.behav['stim_left'][b]
            stim[b, :, 1] = self.behav['stim_right'][b]
            mask[b, :] = self.behav['mask'][b]
            assert np.sum(self.behav['action'][b] == -1) == np.sum(mask[b] == 0)

        device = 'cpu' if 'device' not in format_config else format_config['device']
        assert 'output_h0' not in format_config or not format_config['output_h0']

        act = torch.from_numpy(np.swapaxes(act, 0,1)).to(device=device)  # act shape: trial_num, batch_size, 2
        stim = torch.from_numpy(np.swapaxes(stim, 0,1)).to(device=device) # stim shape: trial_num, batch_size, 2
        rew = torch.from_numpy(np.swapaxes(rew, 0,1)).to(device=device) # rew shape: trial_num, batch_size, 1
        mask = torch.from_numpy(np.swapaxes(mask, 0,1)).to(device=device) # mask shape: trial_num, batch_size
        # input is stim at time t, action at time t-1, reward at time t-1
        input_act_rew = torch.cat([act[:-1], rew[:-1]], -1) # then insert zero at t=0
        input_act_rew = torch.cat([torch.zeros((1, self.batch_size, 3), device=device), input_act_rew], 0)
        input = torch.cat([stim, input_act_rew], -1)
        target = act[:, :, 1]  # 0 for left, 1 for right

        self.torch_beahv_input = input.double()
        self.torch_beahv_target = target.long()
        self.torch_beahv_mask = mask.double()

    def _behav_to_cog_sessions(self, format_config):
        """Transform standard behavioral format to cog_session format, stored in cog_sessions attribute.

        Args:
            format_config: A dict specifies how the standard data should be transformed.
        """
        if self.cog_sessions is not None:
            return
        behav = self.behav

        action = behav['action']
        reward = behav['reward']
        stim = behav['stim_diff']
        mask = behav['mask']
        episode_num = len(reward)

        self.cog_sessions = []
        print('Transforming standard format to cog_session format...')
        print('(episode, trial_num):', end='')
        for epi_idx in range(episode_num):
            trial_num = len(reward[epi_idx])
            print(f'({epi_idx}, {trial_num}),', end='')
            self.cog_sessions.append(
                {'action': action[epi_idx],
                    'reward': reward[epi_idx],
                    'stim': stim[epi_idx],
                    'mask': mask[epi_idx],}
            )
        print('\nTotal block num', episode_num)

def remap_choice_vals(choice):
    # raw choice vector has CW = 1 (correct response for stim on left),
    # CCW = -1 (correct response for stim on right) and viol = 0.  Let's
    # remap so that CW = 0, CCw = 1, and viol = -1
    choice_mapping = {1: 0, -1: 1, 0: -1}
    new_choice_vector = np.vectorize(choice_mapping.get)(choice)
    # new_choice_vector = [choice_mapping[old_choice] for old_choice in choice]
    return new_choice_vector
