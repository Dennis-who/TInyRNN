""" Test whether these datasets work well. """
import pandas as pd
from analyzing_experiments.analyzing import pd_full_print_context
from datasets import Dataset
import numpy as np
from pathlib import Path
from utils import goto_root_dir
from path_settings import *
import joblib
if __name__ == '__main__':
    goto_root_dir.run()

    # uncomment the following lines to test the BartoloMonkey dataset
    # dt = Dataset('BartoloMonkey',
    #         behav_data_spec={'animal_name': 'all', 'filter_block_type': 'both', 'block_truncation': (10, 70)}).behav_to({'behav_format':'tensor'})
    # -----

    # uncomment the following lines to test the MillerRat dataset
    # for rat in [#'m71','m70', 'm64',
    #             'm55']:
    #     dt = Dataset('MillerRat',
    #             behav_data_spec={'animal_name': rat, #'m64',#'m55'
    #                              'max_segment_length': 150,
    #                              },
    #             # neuro_data_spec={'start_time_before_event': -2,
    #             #                     'end_time_after_event': 4,
    #             #      'bin_size': 0.2,}
    #                  ).behav_to({'behav_format':'tensor'})
    #     print(rat, dt.total_trial_num)
    # -----

    # uncomment the following lines to test the SimAgent dataset
    # dt_gru = Dataset('SimAgent',
    #              behav_data_spec={'agent_path': ['allagents_millerrat55_nblocks800_ntrials500'],
    #                               'agent_name': 'GRU_1_seed0',
    #                               }).behav_to({'behav_format': 'tensor'})
    # dt_sgru = Dataset('SimAgent',
    #              behav_data_spec={'agent_path': ['allagents_millerrat55_nblocks800_ntrials500'],
    #                               'agent_name': 'SGRU_1_seed0',
    #                               }).behav_to({'behav_format': 'tensor'})
    # dt_mb = Dataset('SimAgent',
    #              behav_data_spec={'agent_path': ['allagents_millerrat55_nblocks800_ntrials500'],
    #                               'agent_name': 'MB1_seed0',
    #                               }).behav_to({'behav_format': 'tensor'})
    # -----

    # uncomment the following lines to test the AkamRat dataset
    # total_trial_num = 0
    # for rat in ['49']:#, '50', '51', '52', '53', '54', '100', '95', '96', '97', '98', '99', '263', '264', '266', '267', '268']:
    #     dt = Dataset('AkamRat',
    #                  behav_data_spec={'animal_name': rat, 'max_segment_length': 150,
    #                                   }).behav_to({'behav_format': 'tensor'})
    #     print(rat, dt.total_trial_num)
    #     total_trial_num += dt.total_trial_num
    # print(total_trial_num)
    # -----

    # uncomment the following lines to test the AkamRat dataset with sub-indexing
    # behav_data_spec = {'animal_name': 'all', 'max_segment_length': 150, 'include_embedding': True, 'augment': True,
    #                    'behav_format': 'tensor',
    #                    'include_task': True,
    #                    'task_id': 1, 'sub_index_start': 100, 'sub_index_end': 116,
    #                    }

    # uncomment the following lines to test the AkamRat dataset with augmented data
    # dt = Dataset('AkamRat',
    #              behav_data_spec=behav_data_spec).behav_to(behav_data_spec)
    # block_idx_after_aug = dt.get_after_augmented_block_number([0,1,2,3])
    # joblib.dump(dt.data_summary(), ANA_SAVE_PATH / 'AkamRat' / 'subject_summary.pkl')
    # -----

    # uncomment the following lines to test the AkamRat dataset for the reversal learning task and reduced two-step task
    # dt = Dataset('AkamRat',
    #         behav_data_spec={'animal_name': 358, 'max_segment_length': 150,
    #                         'task': 'reversal_learning', }).behav_to({'behav_format':'tensor'})
    # for rat in [269, 270, 271, 272, 273, 274, 275, 277, 278, 279]:
    #     dt = Dataset('AkamRat',
    #                  behav_data_spec={'animal_name': rat, 'max_segment_length': 150,
    #                                   'task': 'no_transition_reversal', }).behav_to({'behav_format': 'tensor'})
    #     print(rat, dt.total_trial_num)
    # joblib.dump(dt.data_summary(), ANA_SAVE_PATH / 'AkamRatRTS' / 'subject_summary.pkl')
    # subject_summary = dt.data_summary()
    # with pd_full_print_context():
    #     print(subject_summary)

    # dt = Dataset('DezfouliHuman',behav_data_spec={'subject_number': 'all', 'include_embedding': True}).behav_to({'behav_format': 'tensor','include_embedding': True})

    # dt = Dataset('CPBHuman',
    #                      behav_data_spec={
    #                                       'max_segment_length': 30,
    #                                       'input_noss': False,
    #                                     'include_embedding': True,
    #                                       }).behav_to({'behav_format':'tensor','include_embedding': True,})
    # print(dt.batch_size)
    # behav_dt = dt.get_behav_data(list(range(dt.batch_size)), {'behav_format':'tensor'})
    # for session_name in ['V20161005', 'V20160929', 'V20160930', 'V20161017']:
    #     neuro_dt = dt.get_neuro_data(session_name=session_name, block_type='where', zcore=True, remove_nan=True, shape=2)[0]
    #     print(neuro_dt.shape)

    # for session_name in ['2015-05-13','2015-05-14','2015-05-19','2015-05-26']:
    #     neuro_dt = dt.get_neuro_data(session_name=session_name, zcore=True, remove_nan=True, shape=2)[0]
    #     print(neuro_dt.shape)

    # from datasets.LaiHumanDataset import LaiHumanDataset
    # data_path = "D:\\OneDrive\\Documents\\git_repo\\cognitive_dynamics\\files"
    # dt = LaiHumanDataset(data_path, behav_data_spec={'group': [0, 1]}).behav_to({'behav_format': 'cog_session',})
    # behav_dt = dt.get_behav_data(list(range(dt.batch_size)), {'behav_format': 'cog_session'})
    
    # dt = Dataset('LaiHuman',behav_data_spec={'group':[0,1]}).behav_to({'behav_format': 'tensor', 'include_cond': True, 'include_sub': True})
    # behav_dt = dt.get_behav_data(list(range(dt.batch_size)), {'behav_format':'tensor'})
    #
    # dt = Dataset('LaiHuman',behav_data_spec={'subjects':[84]}).behav_to({'behav_format': 'cog_session'})
    # behav_dt = dt.get_behav_data(list(range(dt.batch_size)), {'behav_format': 'cog_session'})

    # animal_enough_trials = []
    # for animal in ['IBL-T1',
    #         #        'IBL-T2', 'IBL-T3', 'IBL-T4', 'NYU-01', 'NYU-02', 'NYU-04', 'NYU-06',
    #         # 'CSHL_001', 'CSHL_002', 'CSHL_003', 'CSHL_005', 'CSHL_007', 'CSHL_008', 'CSHL_010', 'CSHL_012',
    #         # 'CSHL_014', 'CSHL_015', 'KS003', 'KS005', 'KS019', 'ZM_1367', 'ZM_1369', 'ZM_1371', 'ZM_1372',
    #         # 'ZM_1743', 'ZM_1745', 'ZM_1746', 'ibl_witten_04', 'ibl_witten_05', 'ibl_witten_06', 'ibl_witten_07',
    #         # 'ibl_witten_12', 'ibl_witten_13', 'ibl_witten_14', 'ibl_witten_15', 'ibl_witten_16'
    #                ]:
    #     dt = Dataset('IBL',behav_data_spec={'animal_name': animal,'output_h0': False}).behav_to({'behav_format': 'tensor'})
    #     if dt.batch_size > 45:
    #         animal_enough_trials.append(animal)
    #     behav_dt = dt.get_behav_data(list(range(dt.batch_size)), {'behav_format': 'tensor'})
    # print(animal_enough_trials)

    # dt = Dataset('MetaTwoStep', {})

    # behav_data_spec = {'animal_name': 'all', 'max_segment_length': 150, 'include_embedding': True,
    #                           'behav_format': 'tensor',
    #                           'include_task': True,
    #                           }
    # dt = Dataset('Omni', behav_data_spec).behav_to(behav_data_spec)

    dt = Dataset('GillanHuman', {'augment':True,
                                 'augment_level': 0,
                                 }
                 ).behav_to({'behav_format': 'tensor', 'output_h0': True})
    # for i in range(dt.batch_size):
    #     a = dt.get_behav_data([i], {'behav_format': 'tensor', 'output_h0': True})
    #     if a['input'].shape[0]!=400: # search for those with <400 trials (due to final few trials being masked)
    #         print(i)

    # dt = Dataset('BahramiHuman', {'augment':0,
    #                              }
    #              ).behav_to({'behav_format': 'tensor',#'cog_session', #
    #                          # 'output_h0': True
    #                          })
    # for i in range(dt.batch_size):
    #     a = dt.get_behav_data([i], {'behav_format': 'tensor', 'output_h0': True})
    #     if a['input'].shape[0]!=150: # search for those with <150 trials (due to final few trials being masked)
    #         print(i)

    # dt = Dataset('SuthaharanHuman', {
    #     'augment': 2
    # }).behav_to({'behav_format': 'tensor',#'cog_session', #
    #              # 'output_h0': True, 'blockinfo': True
    #              })

    # dt = Dataset('Misc',
    #              behav_data_spec={'misc':[
    #                  {
    #                      'dataset': 'SimAgent',
    #                      'label': 0,
    #                     'agent_path': 'RTS_agents_millerrat55',
    #                     'agent_name': 'LS0_seed0',
    #                  },
    #                  {
    #                      'dataset': 'SimAgent',
    #                      'label': 1,
    #                     'agent_path': 'RTS_agents_millerrat55',
    #                     'agent_name': 'MB0_seed0',
    #                  },
    #              ]},
    #              ).behav_to({'behav_format': 'tensor', 'output_h0': True, 'classification_target': 'label'})