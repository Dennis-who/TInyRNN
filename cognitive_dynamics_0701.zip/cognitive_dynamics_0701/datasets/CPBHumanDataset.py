import numpy as np
from .BaseTwoStepDataset import BaseTwoStepDataset, _combine_data_dict, _segment_long_block
import sys
import joblib
from copy import deepcopy
# def block_normalize(X, methods="scale"):
#     assert len(X.shape) <= 2, 'X should be [n_trials, n_blocks or 1]'
#     if methods == "zscore":
#         Z = (X - np.mean(X, axis=0)) / np.std(X, axis=0)
#         Z[np.isnan(Z)] = np.max(Z)
#     elif methods == "range01":
#         Z = (X - np.min(X, axis=0)) / (np.max(X, axis=0) - np.min(X, axis=0))
#         Z[np.isnan(Z)] = X[np.isnan(Z)] / 100
#     elif methods == "scale":
#         Z = X / 100
#     return Z


RT_BOUND = 3
NoSS_BOUND = 20


class ChangingBanditRaw:
    """
    subjects: 0~32, sub 31 has different trial number
    hazard rate: {0.1, 0.2, 0.4}
    num of trials: {100 (pre-ex), 1500 (ex)}
    """
    def __init__(self, file="./datasets/changing_bandit.npy", augment=False):
        raw = np.load(file, allow_pickle=True).item()
        # NoSS < 50 and mean reward > 57, they have good performance maybe because they are lucky
        # lucky_sub_idx = [1, 6, 8, 10, 11, 14, 15, 16, 17, 18, 19, 21, 22, 25, 27, 28, 29, 32]
        rejected_sub_idx = [4, 5, 20, 31]  # NoSS > 100 and mean reward < 55
        idx = list(set(range(33)) - set(rejected_sub_idx))

        self.gender = raw['gender'][idx]
        self.reward = raw['rewards'][idx]
        self.action = raw['actions'][idx] - 1  # map [1, 2] to [0, 1]
        self.ground_truth = raw['ground_truth'][idx]
        self.hazard_rate = raw['hazard_rate'][idx]
        self.block_length = raw['block_length'][idx]
        self.response_time = raw['response_time'][idx]

        if augment:
            self.augment_data()

    def augment_data(self):
        """augment data by adding shadowing subjects"""
        self.gender = np.tile(self.gender, [2])
        self.reward = np.tile(self.reward, [2, 1])
        self.hazard_rate = np.tile(self.hazard_rate, [2, 1])
        self.block_length = np.tile(self.block_length, [2, 1])
        self.response_time = np.tile(self.response_time, [2, 1])

        self.action = np.concatenate([self.action, 1 - self.action], axis=0)
        shadow_gt = np.zeros_like(self.ground_truth)
        shadow_gt[:, :, 0] = self.ground_truth[:, :, 1]
        shadow_gt[:, :, 1] = 1 - self.ground_truth[:, :, 0]
        self.ground_truth = np.concatenate([self.ground_truth, shadow_gt], axis=0)


class HorizonListOfArray(ChangingBanditRaw):
    """
    Returns a list of arrays, each array is a game, each list is one type of feature
    Each array has shape [n_trials, n_features (0 if there is only 1 feature)]
    """
    def __init__(self, file="./datasets/changing_bandit.npy", augment=False):
        super().__init__(file, augment)
        self.reward = self.reward / 100
        self.response_time = np.clip(self.response_time, 0, RT_BOUND)

    def load(self, hazard_rate="all"):
        """
        :param hazard_rate: list of {0.1, 0.2, 0.4, "all"}
        :return: a list of arrays, each array is a game (block), each list is one type of feature
        Returns
        -------
        a dict of inputs, actions and rewards which are lists of n_subs x n_blocks
        """
        if isinstance(hazard_rate, str) and hazard_rate.lower() == 'all':
            hazard_rate = [0.1, 0.2, 0.4]

        data = {
            "gt": [],  # [n_blocks, n_trials]
            "action": [],  # [n_blocks, n_trials]
            "reward": [],  # [n_blocks, n_trials]
            "RT": [],  # [n_blocks, n_trials]
            "NoSS": [],  # [n_blocks, n_trials]
            "sub_ID": [],  # [n_blocks,]
            "gender": [],  # [n_blocks,]
            "hazard_rate": [],  # [n_blocks,]
        }

        for sub in range(self.action.shape[0]):
            for h in hazard_rate:
                idx = (self.hazard_rate[sub, :] == h) * (self.block_length[sub, :] == 1500)
                data["gt"].append(self.ground_truth[sub, idx])
                data["action"].append(self.action[sub, idx])
                data["reward"].append(self.reward[sub, idx])
                data["RT"].append(self.response_time[sub, idx])
                data["sub_ID"].append(sub)
                data["gender"].append(self.gender[sub])
                data["hazard_rate"].append(h)

                NoSS = get_successive_stay(self.action[sub, idx])
                NoSS[NoSS >= NoSS_BOUND] = NoSS_BOUND
                data["NoSS"].append(NoSS)

        return data


def get_successive_stay(actions):
    """how many trials ago the agent shifted
    :param actions: [n_trials,]
    0001111 -> 0120123; 00111000111111 -> 01012012012345
    """
    shift = (actions != np.roll(actions, 1, axis=0)).astype(int)
    n_trials = len(actions)
    successive_stay = np.zeros(n_trials, dtype=np.int32)
    for i in range(n_trials):
        if shift[i] == 1:
            successive_stay[i] = 0
        else:
            successive_stay[i] = successive_stay[i - 1] + 1
    return successive_stay


class CPBHumanDataset(BaseTwoStepDataset):
    """A dataset class for the change-point bandit task.

    Attributes:
         unique_trial_type: How many possible unique trial observations (actions = 2 combinations)
         behav: Standard format of behavioral data.
         data_path: Where to load the data.
         behav_format: tensor (for RNN) or cog_session (for Cog agents)?
         torch_beahv_input: tensor format of agent's input
         torch_beahv_input_1hot: tensor format of agent's input (one-hot encoding of trial observations)
         torch_beahv_target: tensor format of agent's target output
         cog_sessions: cog_session format of agent's input & target output
         batch_size: How many blocks are there in the current loaded data?
    """
    def __init__(self, data_path=None, behav_data_spec=None, neuro_data_spec=None, verbose=False):
        """Initialize the dataset."""

        file = data_path / 'changing_bandit.npy'
        loader = HorizonListOfArray(file, augment=True)
        self.data = loader.load()
        self.unique_trial_type = -1
        super().__init__(data_path, behav_data_spec, neuro_data_spec, verbose=verbose)

    def load_data(self, behav_data_spec, neuro_data_spec=None, verbose=False):
        """Load data from disk following data specifications."""
        if neuro_data_spec is None:
            neuro_data_spec = {}
        self.behav_data_spec = behav_data_spec
        self.neuro_data_spec = neuro_data_spec
        data = self.data
        self._input_noss = 'input_noss' in behav_data_spec and behav_data_spec['input_noss']
        assert not self._input_noss, "NoSS is not implemented yet"
        self.behav = behav = {}
        if 'max_segment_length' in behav_data_spec:
            max_segment_length = behav_data_spec['max_segment_length']
        else:
            max_segment_length = None
        for block in range(len(data["action"])):
            sub_actions = data["action"][block]
            sub_rewards = data["reward"][block]
            sub_noss = data["NoSS"][block]
            sub_id = data["sub_ID"][block]
            if 'subjects' in behav_data_spec:
                subjects = behav_data_spec['subjects']
                if isinstance(subjects, int):
                    subjects = [subjects]
                if sub_id not in subjects:
                    continue
            h = data["hazard_rate"][block]
            action_segments = _segment_long_block(sub_actions.astype(np.int), max_trial_num=max_segment_length, verbose=verbose)
            stage2_segments = _segment_long_block(h * np.ones(sub_actions.shape), max_trial_num=max_segment_length)
            sub_segments = _segment_long_block(sub_id * np.ones(sub_actions.shape), max_trial_num=max_segment_length)
            reward_segments = _segment_long_block(sub_rewards, max_trial_num=max_segment_length)
            noss_segments = _segment_long_block(sub_noss, max_trial_num=max_segment_length)
            print('')
            behav.setdefault('action', []).extend(action_segments) # list of 1d array
            behav.setdefault('stage2', []).extend(stage2_segments)
            behav.setdefault('reward', []).extend(reward_segments)
            behav.setdefault('sub', []).extend(sub_segments)
            if self._input_noss:
                behav.setdefault('noss', []).extend(noss_segments)
        # if self._input_noss: behav['noss_num'] = np.max(np.concatenate(behav['noss'], 0)) + 1
        behav['trial_type'] = deepcopy(behav['action'])
        print("===loaded all===")
        print('Total trial num:', self.total_trial_num)


    def _behav_to_tensor(self, format_config):
        """Transform standard behavioral format to tensor format, stored in torch_beahv_* attribute.

        standard format (list of 1d array) -> tensor format (2d array with 0 padding).
        The attributes are:
            torch_beahv_input: tensor format of agent's input
            torch_beahv_input_1hot: tensor format of agent's input (one-hot encoding of trial observations)
            torch_beahv_target: tensor format of agent's target output
            torch_beahv_mask: tensor format of agent's mask (1 for valid trials, 0 for padding trials)

        Not use nan padding:
            rnn model make all-nan output randomly (unexpected behavior, not sure why)
            the one_hot function cannot accept nan
            long type is required for cross entropy loss, but does not support nan value

        Args:
            format_config: A dict specifies how the standard data should be transformed.

        """
        device = 'cpu' if 'device' not in format_config else format_config['device']
        output_h0 = True if 'output_h0' not in format_config else format_config['output_h0']
        import torch
        import torch.nn as nn
        max_trial_num = max([len(block) for block in self.behav['reward']])
        act = np.zeros((self.batch_size, max_trial_num))
        rew = np.zeros((self.batch_size, max_trial_num))
        stage2 = np.zeros((self.batch_size, max_trial_num))
        sub = np.zeros((self.batch_size, max_trial_num))
        # noss = np.zeros((self.batch_size, max_trial_num))
        mask = np.zeros((self.batch_size, max_trial_num))
        for b in range(self.batch_size):
            this_trial_num = len(self.behav['reward'][b])
            mask[b, :this_trial_num] = 1
            act[b, :this_trial_num] = self.behav['action'][b]
            rew[b, :this_trial_num] = self.behav['reward'][b]
            stage2[b, :this_trial_num] = self.behav['stage2'][b]
            sub[b, :this_trial_num] = self.behav['sub'][b]
            # if self._input_noss:
            #     noss[b, :this_trial_num] = self.behav['noss'][b]

        act = torch.from_numpy(act.T[..., None]).to(device=device)  # act shape: trial_num, batch_size, 1
        stage2 = torch.from_numpy(stage2.T[..., None]).to(device=device)
        rew = torch.from_numpy(rew.T[..., None]).to(device=device)
        include_embedding = 'include_embedding' in format_config and format_config['include_embedding']
        self.include_embedding = include_embedding

        if output_h0:
            input = torch.cat([act, stage2, rew], -1)  # trial_num, batch_size, input_size=3
            target = act[:, :, 0]  # class, not one-hot
            print('output_h0', output_h0, 'h0 included in target')
        else:
            input = torch.cat([act, stage2, rew], -1)[:-1]
            target = act[1:, :, 0]  # class, not one-hot
            print('output_h0', output_h0, 'h0 excluded in target')

        if include_embedding:
            sub = torch.from_numpy(np.swapaxes(sub[..., None], 0,1)).to(device=device)
            input = torch.cat([input, sub], -1) # input shape: trial_num, batch_size, 3+sub_num

        # if self._input_noss:
        #     noss = torch.from_numpy(noss.T[...]).to(device=device) # [trial_num, batch_size], min value = 0
        #     noss = nn.functional.one_hot(noss.to(torch.int64), num_classes=self.behav['noss_num']).double() # [trial_num, batch_size, noss_num]
        #     if output_h0:
        #         input = torch.cat([input, noss], -1)
        #     else:
        #         input = torch.cat([input, noss[:-1]], -1)

        # print(act.shape,rew.shape,input.shape,target.shape)
        self.torch_beahv_input = input.double()
        self.torch_beahv_target = target.long()
        self.torch_beahv_mask = torch.from_numpy(mask.T).to(device=device).double()
        self.torch_beahv_input_1hot = None

