import numpy as np
from .BaseTwoStepDataset import BaseTwoStepDataset
import sys
import joblib
import pandas as pd

def get_grouped_data(game_length, path="./horizon.csv"):
    raw = pd.read_csv(path)  # 86mb
    raw['age_bin'] = pd.cut(raw['age'], bins=[0, 18, 65, 120])
    raw_horizon = raw[raw.game_length == game_length]  # get the data of the given horizon
    grouped = raw_horizon.groupby(['ID', "n_games"])  # group by subject and then the game
    return grouped

class HorizonHumanDataset(BaseTwoStepDataset):
    """A dataset class for the Horizon task.

    Attributes:
         unique_trial_type: How many possible unique trial observations (actions = 2 combinations)
         behav: Standard format of behavioral data.
         data_path: Where to load the data.
         behav_format: tensor (for RNN) or cog_session (for Cog agents)?
         torch_beahv_input: tensor format of agent's input
         torch_beahv_input_1hot: tensor format of agent's input (one-hot encoding of trial observations)
         torch_beahv_target: tensor format of agent's target output
         cog_sessions: cog_session format of agent's input & target output
         batch_size: How many blocks are there in the current loaded data?
    """
    def __init__(self, data_path=None, behav_data_spec=None, neuro_data_spec=None):
        """Initialize the dataset."""
        self.unique_trial_type = -1
        self.data_path = data_path / "horizon.csv"
        super().__init__(data_path, behav_data_spec, neuro_data_spec)

    def load_data(self, behav_data_spec, neuro_data_spec=None):
        """Load data from disk following data specifications."""
        if neuro_data_spec is None:
            neuro_data_spec = {}
        self.behav_data_spec = behav_data_spec
        self.neuro_data_spec = neuro_data_spec

        horizon = behav_data_spec['horizon']
        assert horizon in [1, 6], "Horizon must be 1 or 6"
        N_FORCED_TRIALS = 4
        game_length = horizon + N_FORCED_TRIALS
        grouped = get_grouped_data(game_length, self.data_path)

        self.action = np.array(grouped['choice'].agg(list).tolist(), dtype=np.float32) - 1  # change action 1/2 to 0/1
        self.reward = np.array(grouped['reward'].agg(list).tolist(), dtype=np.float32) / 100  # normalize reward to 0-1
        RT = np.array(grouped['response_time'].agg(list).tolist(), dtype=np.float32)
        self.RT = np.clip(RT, 0, 10)  # clip RT to 0-10s

        sub_ID = grouped.apply(lambda x: x['ID'].iloc[0]).values
        age_bin = grouped.apply(lambda x: x['age_bin'].iloc[0]).values
        gender = grouped.apply(lambda x: x['gender'].iloc[0]).values
        sub_emb = pd.get_dummies(sub_ID).values
        age_emb = pd.get_dummies(age_bin).values
        gender_emb = pd.get_dummies(gender).values
        sub_info = np.concatenate([sub_emb, gender_emb, age_emb], axis=1)
        self.sub_info = np.tile(sub_info[:, None, :], [1, game_length, 1])

        n_games = len(self.action)
        forced = np.array(grouped['forced'].agg(list).tolist(), dtype=np.float32)
        trial_left = np.array([game_length - i for i in range(game_length)], dtype=np.float32) / 10  # normalize to 0-1
        trial_left = np.tile(trial_left[None, :], [n_games, 1])
        self.task_info = np.concatenate([trial_left[:, :, None], forced[:, :, None]], axis=2)



        print('Total trial num:', self.total_trial_num)

    def load_a_block(self, sub, hazard_rate, n_trials=1500):
        """
        Return:
            inputs: [n_trials, 2 (rewards in the left and right)]
            actions: [n_trials,]
            rewards: [n_trials,]
        """
        idx = (self.raw['hazard_rate'][sub, :] == hazard_rate) \
              * (self.raw['block_length'][sub, :] == n_trials)

        inputs = self.raw['states'][sub, idx]
        actions = self.raw['actions'][sub, idx] - 1  # map [1, 2] to [0, 1]
        rewards = self.raw['rewards'][sub, idx]
        rewards = block_normalize(rewards, methods="scale")
        return inputs, actions, rewards


    def _behav_to_tensor(self, format_config):
        """Transform standard behavioral format to tensor format, stored in torch_beahv_* attribute.

        standard format (list of 1d array) -> tensor format (2d array with 0 padding).
        The attributes are:
            torch_beahv_input: tensor format of agent's input
            torch_beahv_input_1hot: tensor format of agent's input (one-hot encoding of trial observations)
            torch_beahv_target: tensor format of agent's target output
            torch_beahv_mask: tensor format of agent's mask (1 for valid trials, 0 for padding trials)

        Not use nan padding:
            rnn model make all-nan output randomly (unexpected behavior, not sure why)
            the one_hot function cannot accept nan
            long type is required for cross entropy loss, but does not support nan value

        Args:
            format_config: A dict specifies how the standard data should be transformed.

        """
        device = 'cpu' if 'device' not in format_config else format_config['device']
        output_h0 = True if 'output_h0' not in format_config else format_config['output_h0']
        import torch
        import torch.nn as nn
        max_trial_num = max([len(block) for block in self.behav['reward']])
        act = np.zeros((self.batch_size, max_trial_num))
        rew = np.zeros((self.batch_size, max_trial_num))
        stage2 = np.zeros((self.batch_size, max_trial_num))
        noss = np.zeros((self.batch_size, max_trial_num))
        mask = np.zeros((self.batch_size, max_trial_num))
        for b in range(self.batch_size):
            this_trial_num = len(self.behav['reward'][b])
            mask[b, :this_trial_num] = 1
            act[b, :this_trial_num] = self.behav['action'][b]
            rew[b, :this_trial_num] = self.behav['reward'][b]
            stage2[b, :this_trial_num] = self.behav['stage2'][b]
            if self._input_noss:
                noss[b, :this_trial_num] = self.behav['noss'][b]

        act = torch.from_numpy(act.T[..., None]).to(device=device)  # act shape: trial_num, batch_size, 1
        stage2 = torch.from_numpy(stage2.T[..., None]).to(device=device)
        rew = torch.from_numpy(rew.T[..., None]).to(device=device)
        if output_h0:
            input = torch.cat([act, stage2, rew], -1)  # trial_num, batch_size, input_size=3
            target = act[:, :, 0]  # class, not one-hot
            print('output_h0', output_h0, 'h0 included in target')
        else:
            input = torch.cat([act, stage2, rew], -1)[:-1]
            target = act[1:, :, 0]  # class, not one-hot
            print('output_h0', output_h0, 'h0 excluded in target')
        if self._input_noss:
            noss = torch.from_numpy(noss.T[...]).to(device=device) # [trial_num, batch_size], min value = 0
            noss = nn.functional.one_hot(noss.to(torch.int64), num_classes=self.behav['noss_num']).double() # [trial_num, batch_size, noss_num]
            if output_h0:
                input = torch.cat([input, noss], -1)
            else:
                input = torch.cat([input, noss[:-1]], -1)

        # print(act.shape,rew.shape,input.shape,target.shape)
        self.torch_beahv_input = input.double()
        self.torch_beahv_target = target.long()
        self.torch_beahv_mask = torch.from_numpy(mask.T).to(device=device).double()
        self.torch_beahv_input_1hot = None

    def get_NoSS(self, actions):
        """get successive stay (how many trials ago the agent shift)
        0001111 -> 0120123; 00111000111111 -> 01012012012345
        """
        shift = (actions != np.roll(actions, 1, axis=0)).astype(int)
        n_trials = len(actions)
        last_shift = np.zeros(n_trials, dtype=np.int32)
        for i in range(n_trials):
            if shift[i] == 1:
                last_shift[i] = 0
            else:
                last_shift[i] = last_shift[i - 1] + 1
        return last_shift