from datasets import Dataset
import numpy as np
import os
import matplotlib.pyplot as plt
from utils import goto_root_dir
import pandas as pd
goto_root_dir.run()
dt = Dataset('DezfouliHuman',behav_data_spec={'subject_number': 'all'})
import matplotlib as mpl
mpl.rcParams['font.size'] = 8
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['font.family'] = 'arial'
mpl.rcParams['savefig.dpi'] = 480

def find_switching_indices(actions):
    # Prepare the target sequences to match
    patterns = [
        np.array([0, 1, 0, 1]),
        np.array([1, 0, 1, 0])
    ]
    switching_indices = []

    # Iterate over the array to find matches with either pattern
    for i in range(len(actions)):
        for patt in patterns:
            if np.array_equal(actions[i:i + len(patt)], patt):
                switching_indices.append([i, i + len(patt) - 1]) # right inclusive

    merged = []
    for interval in switching_indices:
        # If merged is empty or the current interval does not overlap with the last one added, append it
        if not merged or merged[-1][1]+1 < interval[0]:
            merged.append(interval)
        else:
            # Else, there is an overlap, merge the current interval with the last one in merged
            merged[-1][1] = max(merged[-1][1], interval[1])
    return merged

ID2num = dt.ID2num
num2ID = {v: k for k, v in ID2num.items()}
plot=False
switch_prop_pd = []
for i in range(len(dt.behav['sub_id'])):
    sub_id = dt.behav['sub_id'][i][0]
    sub_name = num2ID[sub_id]
    block = dt.behav['block'][i]
    action = dt.behav['action'][i]
    reward = dt.behav['reward'][i]
    n_trial = len(action)
    switching_indices = find_switching_indices(action) # indices of switching intervals
    switching_trial_array = []
    non_switching_trial_array = []
    for interval_idx in range(len(switching_indices)):
        interval = switching_indices[interval_idx]
        switching_trial_array.append(np.arange(interval[0], interval[1]+1))
        if interval_idx < len(switching_indices) - 1:
            non_switching_trial_array.append(np.arange(interval[1]+1, switching_indices[interval_idx+1][0]))
        elif interval_idx == len(switching_indices) - 1:
            non_switching_trial_array.append(np.arange(interval[1]+1, n_trial))
        elif interval_idx == 0:
            non_switching_trial_array.append(np.arange(0, interval[0]))
    n_switching_trials = len(np.concatenate(switching_trial_array)) if len(switching_trial_array) > 0 else 0
    non_switching_trial_array = np.setdiff1d(np.arange(n_trial), np.concatenate(switching_trial_array) if len(switching_trial_array) > 0 else np.array([]))
    # remove the last trial of each interval to avoid edge effect
    switching_trial_array = np.concatenate([x[:-1] for x in switching_trial_array]) if len(switching_trial_array) > 0 else np.array([], dtype=int)
    is_stay = (action[:-1] == action[1:])
    is_reward = (reward[:-1] == 1)
    is_no_reward = (reward[:-1] == 0)

    n_stay_after_reward = np.sum(is_stay & is_reward)
    n_stay_after_no_reward = np.sum(is_stay & is_no_reward)
    n_reward = np.sum(is_reward)
    n_no_reward = np.sum(is_no_reward)

    # removing the last trial of each block if in  switching_trial_array or non_switching_trial_array
    if n_trial - 1 in switching_trial_array:
        switching_trial_array = switching_trial_array[:-1]
    if n_trial - 1 in non_switching_trial_array:
        non_switching_trial_array = non_switching_trial_array[:-1]
    n_stay_after_reward_switch = np.sum(is_stay[switching_trial_array] & is_reward[switching_trial_array])
    n_stay_after_no_reward_switch = np.sum(is_stay[switching_trial_array] & is_no_reward[switching_trial_array])
    n_reward_switch = np.sum(is_reward[switching_trial_array])
    n_no_reward_switch = np.sum(is_no_reward[switching_trial_array])

    n_stay_after_reward_non_switch = np.sum(is_stay[non_switching_trial_array] & is_reward[non_switching_trial_array])
    n_stay_after_no_reward_non_switch = np.sum(is_stay[non_switching_trial_array] & is_no_reward[non_switching_trial_array])
    n_reward_non_switch = np.sum(is_reward[non_switching_trial_array])
    n_no_reward_non_switch = np.sum(is_no_reward[non_switching_trial_array])

    if block == 1:
        if plot:
            plt.figure(figsize=(10, 5))
        n_trial_max = 0
        n_trial_total = 0
        n_switching_trials_total = 0

        n_stay_after_reward_total = 0
        n_reward_total = 0
        n_stay_after_no_reward_total = 0
        n_no_reward_total = 0

        n_stay_after_reward_switch_total = 0
        n_stay_after_no_reward_switch_total = 0
        n_reward_switch_total = 0
        n_no_reward_switch_total = 0

        n_stay_after_reward_non_switch_total = 0
        n_stay_after_no_reward_non_switch_total = 0
        n_reward_non_switch_total = 0
        n_no_reward_non_switch_total = 0


    n_trial_max = max(n_trial_max, n_trial)
    n_trial_total += n_trial
    n_switching_trials_total += n_switching_trials

    n_stay_after_reward_total += n_stay_after_reward
    n_reward_total += n_reward
    n_stay_after_no_reward_total += n_stay_after_no_reward
    n_no_reward_total += n_no_reward

    n_stay_after_reward_switch_total += n_stay_after_reward_switch
    n_stay_after_no_reward_switch_total += n_stay_after_no_reward_switch
    n_reward_switch_total += n_reward_switch
    n_no_reward_switch_total += n_no_reward_switch

    n_stay_after_reward_non_switch_total += n_stay_after_reward_non_switch
    n_stay_after_no_reward_non_switch_total += n_stay_after_no_reward_non_switch
    n_reward_non_switch_total += n_reward_non_switch
    n_no_reward_non_switch_total += n_no_reward_non_switch

    if plot:
        plt.scatter(np.arange(n_trial), block*2 + action, c=[['grey', 'red'][r] for r in reward], s=10)
    for interval in switching_indices:
        if plot:
            # fill between the switching trials
            plt.fill_between(interval, block*2, block*2 + 1, color='blue', alpha=0.3)
    if block == 12:
        print(sub_id)
        switching_proportion = n_switching_trials_total/n_trial_total
        reward_stay_prob = n_stay_after_reward_total/n_reward_total
        no_reward_stay_prob = n_stay_after_no_reward_total/n_no_reward_total
        reward_stay_switch_prob = n_stay_after_reward_switch_total/n_reward_switch_total
        no_reward_stay_switch_prob = n_stay_after_no_reward_switch_total/n_no_reward_switch_total
        reward_stay_non_switch_prob = n_stay_after_reward_non_switch_total/n_reward_non_switch_total
        no_reward_stay_non_switch_prob = n_stay_after_no_reward_non_switch_total/n_no_reward_non_switch_total
        switch_prop_pd.append([sub_id, sub_name, switching_proportion, reward_stay_prob, no_reward_stay_prob,
                               reward_stay_switch_prob, no_reward_stay_switch_prob,
                               reward_stay_non_switch_prob, no_reward_stay_non_switch_prob])
        if plot:
            plt.hlines(1.5 + np.arange(2, 26, 2), -1, n_trial_max, color='black', linewidth=0.5)
            plt.yticks(0.5 + np.arange(2, 26, 2), ['block-' + str(i) for i in range(1,13)])
            plt.ylim(1.5, 25.5)
            plt.xlabel('Trial')
            plt.xlim(-1, n_trial_max)
            plt.title(f'sub_id: {int(sub_id)} ({sub_name}) switching proportion: {switching_proportion:.2f}')
            os.makedirs('dezfouli_human', exist_ok=True)
            prefix = '20230930010700_Subj'
            plt.savefig(f"dezfouli_human/{prefix}{int(sub_id)}.png", bbox_inches='tight')
            plt.show()
            plt.close()

            plt.figure(figsize=(3, 3))
            plt.bar(['reward', 'no reward'], [reward_stay_prob, no_reward_stay_prob], color='grey')
            plt.ylim(0, 1)
            plt.hlines(0.5, -0.5, 1.5, color='black', linestyle='--')
            plt.ylabel('Stay prob.')
            plt.title(f'sub_id: {int(sub_id)} ({sub_name})')
            plt.savefig(f"dezfouli_human/{prefix}{int(sub_id)}_stay_prob.png", bbox_inches='tight')
            plt.show()
            plt.close()

switch_prop_pd = pd.DataFrame(switch_prop_pd, columns=['sub_id', 'sub_name', 'switching_proportion', 'reward_stay_prob', 'no_reward_stay_prob',
                                                       'reward_stay_switch_prob', 'no_reward_stay_switch_prob',
                                                       'reward_stay_non_switch_prob', 'no_reward_stay_non_switch_prob'])
switch_prop_pd.to_csv('dezfouli_human/switch_prop.csv', index=False)

dt = switch_prop_pd[switch_prop_pd['switching_proportion']<0.05]
plt.figure(figsize=(2, 2))
plt.scatter(dt['reward_stay_prob'],dt['no_reward_stay_prob'], s=5, facecolor='none', edgecolor='grey')
plt.plot([0,1],[0,1],'k-', linewidth=0.3)
plt.plot([0,1],[0.5,0.5],'k-', linewidth=0.3)
plt.plot([0.5,0.5],[0,1],'k-', linewidth=0.3)
plt.xlabel('Stay prob. (after reward)')
plt.ylabel('Stay prob. (after no reward)')
plt.xticks([0, 0.5, 1])
plt.yticks([0, 0.5, 1])
plt.xlim(-0.05, 1.05)
plt.ylim(-0.05, 1.05)
plt.savefig('dezfouli_human/stay_prob_no_switch.pdf', bbox_inches='tight')
plt.show()

dt = switch_prop_pd[switch_prop_pd['switching_proportion']>0.8]
plt.figure(figsize=(2, 2))
plt.scatter(dt['reward_stay_prob'],dt['no_reward_stay_prob'], s=5, facecolor='none', edgecolor='blue')
plt.plot([0,1],[0,1],'k-', linewidth=0.3)
plt.plot([0,1],[0.5,0.5],'k-', linewidth=0.3)
plt.plot([0.5,0.5],[0,1],'k-', linewidth=0.3)
plt.xlabel('Stay prob. (after reward)')
plt.ylabel('Stay prob. (after no reward)')
plt.xticks([0, 0.5, 1])
plt.yticks([0, 0.5, 1])
plt.xlim(-0.05, 1.05)
plt.ylim(-0.05, 1.05)
plt.savefig('dezfouli_human/stay_prob_all_switch.pdf', bbox_inches='tight')
plt.show()

dt = switch_prop_pd[(switch_prop_pd['switching_proportion']>=0.05) & (switch_prop_pd['switching_proportion']<=0.8)]
plt.figure(figsize=(2, 2))
plt.scatter(dt['reward_stay_switch_prob'],dt['no_reward_stay_switch_prob'], s=5, facecolor='none', edgecolor='blue')
plt.scatter(dt['reward_stay_non_switch_prob'],dt['no_reward_stay_non_switch_prob'], s=5, facecolor='none', edgecolor='grey')
for i in range(dt.shape[0]): # connect the two points
    plt.plot([dt['reward_stay_switch_prob'].iloc[i], dt['reward_stay_non_switch_prob'].iloc[i]],
             [dt['no_reward_stay_switch_prob'].iloc[i], dt['no_reward_stay_non_switch_prob'].iloc[i]], 'k-', linewidth=0.1)
plt.plot([0,1],[0,1],'k-', linewidth=0.3)
plt.plot([0,1],[0.5,0.5],'k-', linewidth=0.3)
plt.plot([0.5,0.5],[0,1],'k-', linewidth=0.3)
plt.xlabel('Stay prob. (after reward)')
plt.ylabel('Stay prob. (after no reward)')
plt.xticks([0, 0.5, 1])
plt.yticks([0, 0.5, 1])
plt.xlim(-0.05, 1.05)
plt.ylim(-0.05, 1.05)
plt.savefig('dezfouli_human/stay_prob_mix_switch.pdf', bbox_inches='tight')
plt.show()