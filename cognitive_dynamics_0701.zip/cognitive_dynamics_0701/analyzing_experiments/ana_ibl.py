from analyzing_experiments.analyzing_dynamics import *
from analyzing_experiments.analyzing_perf import *
from analyzing_experiments.analyzing_check import *
from analyzing_experiments.analyzing_decoding import *
from utils import goto_root_dir
goto_root_dir.run()

analyzing_pipeline = [
    # 'analyze_model_perf_for_each_exp',
    'compile_perf_for_all_exps',
    # 'extract_model_par',
    # 'run_scores_for_each_exp',
    # 'run_2d_inits_for_each_exp',
    # 'extract_1d_for_each_exp',
]

exp_folders = [
    # 'exp_iblIBL-T1',
    # 'exp_iblIBL-T4',
    'exp_iblNYU-01',
    # 'exp_iblNYU-02',
    'exp_iblNYU-04',
    'exp_iblCSHL_002',
    # 'exp_iblCSHL_003',
    # 'exp_iblCSHL_005',
    'exp_iblCSHL_007',
    # 'exp_iblCSHL_008',
    # 'exp_iblCSHL_010',
    'exp_iblCSHL_014',
    'exp_iblCSHL_015',
    # 'exp_iblKS003',
    # 'exp_iblZM_1369',
    # 'exp_iblZM_1371',
    # 'exp_iblZM_1372',
    # 'exp_iblZM_1743',
    # 'exp_iblZM_1745',
    # 'exp_iblibl_witten_04',
    # 'exp_iblibl_witten_05',
    # 'exp_iblibl_witten_06',
    # 'exp_iblibl_witten_07',
    # 'exp_iblibl_witten_12',
    # 'exp_iblibl_witten_13',
    # 'exp_iblibl_witten_16',
]

# perf
if 'analyze_model_perf_for_each_exp' in analyzing_pipeline:
    for exp_folder in exp_folders:
        find_best_models_for_exp(exp_folder, '',
                                 has_cog=False,
                                 )

if 'compile_perf_for_all_exps' in analyzing_pipeline:
    compile_perf_for_exps(exp_folders, 'exp_ibl',has_cog=False)

if 'extract_model_par' in analyzing_pipeline:
    extract_model_par(exp_folders[0])

# dynamics
for exp_folder in exp_folders:
    if 'run_scores_for_each_exp' in analyzing_pipeline:
        run_scores_exp(exp_folder)
    if 'run_2d_inits_for_each_exp' in analyzing_pipeline:
        run_2d_inits_exp(exp_folder, grid_num=50)


if 'extract_1d_for_each_exp' in analyzing_pipeline:
    for exp_folder in exp_folders:
        extract_1d_logit_for_exp(exp_folder)

