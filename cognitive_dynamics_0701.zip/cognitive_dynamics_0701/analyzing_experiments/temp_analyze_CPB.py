import os

from analyzing import *
import torch
import torch.nn as nn
from tqdm import tqdm
import seaborn as sns
import torch.nn.functional as F
import matplotlib.pyplot as plt
from scipy.stats.mstats import gmean

def get_NoSS(actions):
    """get successive stay (how many trials ago the agent shift)
    0001111 -> 0120123; 00111000111111 -> 01012012012345
    """
    shift = (actions != np.roll(actions, 1, axis=0)).astype(int)
    n_trials = len(actions)
    last_shift = np.zeros(n_trials, dtype=np.int32)
    for i in range(n_trials):
        if shift[i] == 1:
            last_shift[i] = 0
        else:
            last_shift[i] = last_shift[i - 1] + 1
    return last_shift


def load_probe_data(r_kwn, r_unk, n, gt, action, reward, curr_action, start, hazard_rate=0.1, contain_noss=False):
    """generate probe data with fixed r_kwn, r_unk, n
    start: trials num of starting shift, trials before start is used to
        warm-up meta RL
    states: [start+n+1, batch_size, 2 (action, stage2=h, reward)]
    """
    assert r_kwn>=1 and r_unk>=1
    batch_size = gt.shape[1]
    states = np.zeros([start + n + 1, batch_size, 3])
    states[:start, :, 0] = action[:start, :]  # warm up real action data
    states[start, :, 0] = 1 - curr_action  # first shift trial (unknown)
    states[start + 1:, :, 0] = curr_action  # successive stay (known)
    states[:, :, 1] = hazard_rate
    states[:start, :, 2] = reward[:start, :]  # warm up real reward data
    states[start, :, 2] = r_unk  # reward of first shift trial
    r_stay = [gt[start + 1: start + 1 + n, b, curr_action[b]] for b in range(batch_size)]
    states[start + 1:, :, 2] = np.array(r_stay).T  # gt reward given action
    states[start + n, :, 2] = r_kwn  # reward of last shift trial
    states[:,:,2] = states[:,:,2] / 100
    if contain_noss:
        sub_actions = states[:, :, 0]
        noss = np.zeros(sub_actions.shape)  # [trial_num, batch_size]
        for i in range(batch_size):
            noss[:, i] = get_NoSS(sub_actions[:, i].astype(np.int))
        assert np.min(noss) == 0
        noss[noss >= 10] = 10 # cap the NoSS to 10, here NoSS starts from 0
        noss_num = 11
        noss = torch.from_numpy(noss)  # [trial_num, batch_size], min value = 0
        noss = nn.functional.one_hot(noss.to(torch.int64),
                                     num_classes=noss_num).double()  # [trial_num, batch_size, noss_num]
        states = torch.cat([torch.as_tensor(states), noss], -1)
    return torch.as_tensor(states[:start + 1 + n, :, :], dtype=torch.float64,device='cuda')


def get_decision_boundary(model, reward_pool, last_shift, gt, action, reward,
                          hidden=None, start=20, contain_noss=False):
    """get decision boundary of a RNN model
    gt are real data, action and reward are generated from meta-RL

    gt: [n_trials, batch_size, rewards in two slots]
    action: [n_trials, batch_size]
    reward: [n_trials, batch_size]
    hidden: warmed meta-RL hidden
    """
    assert gt.shape[1] % 2 == 0, "batch size should be 2*n"
    curr_action = np.array([0, 1] * int(gt.shape[1] / 2))
    action_probs = np.zeros([len(reward_pool), len(reward_pool)])

    with torch.no_grad():
        for r_kwn in tqdm(reward_pool):
            for r_unk in reward_pool:
                inputs = load_probe_data(r_kwn, r_unk, last_shift, gt, action,
                                         reward, curr_action, start, contain_noss=contain_noss)
                outputs_dict = model(inputs)
                scores = outputs_dict['output']
                pi = scores[-1,...]
                #print(r_kwn, r_unk, scores[:,0])
                # for i in range(inputs.shape[0]):
                #     pi, v, hidden = model.forward(inputs[i, :, :], hidden)

                action_prob = F.softmax(pi, dim=1).detach().cpu().numpy()
                #print(action_prob)
                curr_action_prob = np.choose(curr_action, action_prob.T)
                action_probs[r_kwn - 1, r_unk - 1] = gmean(curr_action_prob)
            #sysss

    return action_probs

def get_DB_line(shift_probs):
    shift_DB = (shift_probs >= 0.5).astype(np.int32)
    shift_DB = np.roll(shift_DB, shift=1, axis=1) - shift_DB
    shift_DB = np.argmax(shift_DB, axis=1)
    return shift_DB


def plot_DB_line(shift_probs, ax, n, color):
    shift_DB = get_DB_line(shift_probs)
    if np.max(shift_DB) == 0:
        shift_DB += 1
    idx = (shift_DB > 0)
    #print(shift_DB, np.max(shift_DB))
    #     ax.vlines(0, 1, 99, linewidth=1, label=f'{n}',
    #         colors=color, alpha=0.9)
    #     ax.plot(shift_DB, np.arange(1, 100), linewidth=1, label=f'{n}',
    #         c=color, alpha=0.9)
    # else:
    ax.plot(shift_DB[idx], np.arange(1, 100)[idx], linewidth=1, label=f'{n}',
            c=color, alpha=0.9)
    ax.legend(fontsize=11)
    leg = ax.legend(loc='upper left', fancybox=True, shadow=False, ncol=1)
    leg.set_title('NoSS')
    ax.set_xticks([1, 50, 99], [0, 50, 100])
    ax.set_xlim([0.5, 99])
    ax.set_yticks([1, 50, 99], [0, 50, 100])
    ax.set_xlabel("Current Reward", fontsize=14)
    ax.set_ylabel("Other Reward", fontsize=14)
    ax.tick_params('both', labelsize=13)
    ax.set_ylim(bottom=1)


def plot_decision_boundary(shift_probs, title, DB_line=True):
    plt.figure(figsize=[6, 4], dpi=300)
    ax = sns.heatmap(shift_probs, cmap='bwr', center=0.5, vmin=0, vmax=1)

    if DB_line is True:
        shift_DB = get_DB_line(shift_probs)
        plt.plot(shift_DB, np.arange(1, 100), 'k', linestyle=(0, (0.05, 3)),
                 linewidth=2, dash_capstyle='round', alpha=0.8)

    cbar = ax.collections[0].colorbar
    cbar.set_ticks([0, 0.5, 1])
    cbar.ax.tick_params(labelsize=16)
    cbar.set_label("Shift Prob.", fontsize=16)
    ax.set_title(f"{title}", fontsize=16)
    ax.set_xticks([0, 50, 99], [0, 50, 100], rotation=0)  # , np.arange(0, reward+1, 20), rotation=0)
    ax.set_yticks([0, 50, 99], [0, 50, 100])  # np.arange(0, reward+1, 20), np.arange(0, reward+1, 20))
    ax.set_xlabel("Current Reward", fontsize=16)
    ax.set_ylabel("Other Reward", fontsize=16)
    ax.invert_yaxis()
    ax.tick_params('both', labelsize=15)
    plt.grid()
    # plt.savefig(f'./results/DB_{title}.png', **PLOT_PARAMS_HD)
    # plt.close()


if __name__ == "__main__":
    goto_root_dir.run()
    exp_folder = 'exp_seg_CPB'  # 'exp_monkeyV'
    # find_best_models_for_exp(exp_folder, 'CPBCog', additional_rnn_keys={'model_identifier_keys': ['input_dim']})
    # syss
    #model_paths = get_model_path_in_exp(exp_folder)
    # [print(i, m) for i,m in enumerate(model_paths)]
    # syss
    model_identifier_keys = ['rnn_type', 'hidden_dim', 'readout_FC']
    cv_keys = ['outer_fold', 'inner_fold']
    compete_from_keys = ['l1_weight', 'seed']
    # cs = combine_exp_summary(exp_folder, added_keys=model_identifier_keys+cv_keys+compete_from_keys, filter_dict={'agent_type': 'RNN'})
    # print(cs)
    n_trials = 100
    hazard_rate = 0.1
    n_blocks = 100
    batch_size = 32
    reward = 99
    reward_pool = [i + 1 for i in range(reward)]

    file = r'C:\Users\lijia\OneDrive\Documents\git_repo\explore-exploit\MF_H01_data.npy'
    warmup_data = np.load(file, allow_pickle=True).item()
    gt = warmup_data['gt'][:, :batch_size, :]
    action = warmup_data['actions'][:, :batch_size]
    reward = warmup_data['rewards'][:, :batch_size]

    for model_path in [
        #Path(r'files\saved_model\exp_seg_CPB\rnn_type-GRU.hidden_dim-10.readout_FC-True.l1_weight-1e-05\outerfold0_innerfold0_seed2'),
        Path(r'files\saved_model\exp_seg_CPB\rnn_type-GRU.hidden_dim-10.readout_FC-True.l1_weight-1e-05\outerfold0_innerfold2_seed1'),
        #Path(r'files\saved_model\exp_seg_CPB\rnn_type-GRU.hidden_dim-10.readout_FC-True.l1_weight-1e-05.input_dim-14\outerfold0_innerfold2_seed1'),
    ]:
        #model_paths:  #
        if 'rnn_type' not in str(model_path):
            continue

        with set_posix_windows():
            config = joblib.load(model_path / 'config.pkl')
            config['model_path'] = Path(str(config['model_path']))
        ag = Agent('RNN', config=config)
        ag.load(config['model_path'], strict=False)  # for the dummy variable
        shift_probs_dict = {}
        last_shift_list = [1, 2, 3, 4, 5, 6,7,8,9, 10]
        figure_path_ = Path(r'C:\Users\lijia\OneDrive\Documents\git_repo\cognitive_dynamics\figures\decision_boundary') /model_path.parent.name / model_path.name
        for last_shift in last_shift_list:
            figure_path = figure_path_  /f"DB_{last_shift}.png"
            print(figure_path)
            # if os.path.exists(figure_path):
            #     continue
            os.makedirs(figure_path.parent, exist_ok=True)
            stay_probs = get_decision_boundary(ag, reward_pool, last_shift, gt,
                                                 action, reward, contain_noss=False)
            shift_probs = 1 - stay_probs.T
            shift_probs_dict[last_shift] = shift_probs
            plt.figure()
            title = f'metaRL0_Gmean_[h = {hazard_rate}, NoSS = {last_shift}]'
            plot_decision_boundary(shift_probs, title)

            plt.savefig(figure_path)

        fig, ax = plt.subplots(figsize=(6, 5))
        cmap = plt.get_cmap('viridis')
        for last_shift in last_shift_list:
            shift_probs = shift_probs_dict[last_shift]
            color = cmap(last_shift / 10)
            plot_DB_line(shift_probs, ax, last_shift, color)
        title = 'MF_all_[h01]'
        plt.grid()
        plt.savefig(figure_path_ /'DB.png')
        plt.close()
        joblib.dump(shift_probs_dict, figure_path_ /'shift_probs_dict.pkl')
        np.save(str(figure_path_ /'shift_probs_dict.npy'), shift_probs_dict)