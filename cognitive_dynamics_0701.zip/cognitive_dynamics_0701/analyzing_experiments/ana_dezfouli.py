from analyzing_experiments.analyzing_dynamics import *
from analyzing_experiments.analyzing_perf import *
from analyzing_experiments.analyzing_check import *
from analyzing_experiments.analyzing_decoding import *
from utils import goto_root_dir
goto_root_dir.run()

analyzing_pipeline = [
    # 'analyze_model_perf_for_each_exp',
    # 'compile_perf_for_all_exps',
    # 'extract_subject_model_par',
    # 'extract_model_par',
    # 'logit_vs_action_freq',
    # 'action_freq_after_action_seq',
    'run_scores_for_each_exp',
    # 'run_scores_for_each_exp_best_for_test',
    # 'run_2d_inits_for_each_exp',
    # 'extract_1d_for_each_exp',
]

exp_folders = [
'exp_dezfouliAll',
# 'exp_dezfouli67',
# 'exp_dezfouli71',
# 'exp_dezfouli75',
# 'exp_dezfouli76',
# 'exp_dezfouli77',
# 'exp_dezfouli78',
# 'exp_dezfouli84',
# 'exp_dezfouli90',
]

# perf
if 'analyze_model_perf_for_each_exp' in analyzing_pipeline:
    for exp_folder in exp_folders:
        find_best_models_for_exp(exp_folder, 'PRLCog',additional_rnn_keys={'model_identifier_keys': ['include_embedding','embedding_dim',]},
                                 additional_cog_keys={'model_identifier_keys': ['subject_number']},
                                 rnn_sort_keys=[#'hidden_dim'
                                                ],
                                 cog_sort_keys=['subject_number'],
                                 has_cog=False,
                                 has_rnn=True
                                 )

if 'compile_perf_for_all_exps' in analyzing_pipeline:
    # compile_perf_for_exps(exp_folders, 'exp_dezfouli')
    compile_perf_for_exps(exp_folders, 'exp_dezfouli_sub_avg',
                          has_rnn=False,
                          )

if 'extract_subject_model_par' in analyzing_pipeline:
    for exp_folder in exp_folders:
        dt = []
        ana_exp_path = ANA_SAVE_PATH / exp_folder
        print(ana_exp_path)
        from utils import set_os_path_auto
        with set_os_path_auto():
            cog_summary = joblib.load(ana_exp_path / 'cog_final_best_summary.pkl')
        for i, row in cog_summary.iterrows():
            config = transform_model_format(row, source='row', target='config')
            ag = transform_model_format(config, source='config', target='agent')
            dt.append({
                'cog_type': row['cog_type'], # 'MB0'
                'subject_number': row['subject_number'],
                'hidden_dim': row['hidden_dim'],
                'outer_fold': row['outer_fold'],
                'params': ag.model.params,}
            )
        # sort
        dt = pd.DataFrame(dt)
        dt = dt.sort_values(['hidden_dim','cog_type', 'subject_number'])
        print(dt)
        joblib.dump(dt, ana_exp_path / f'cog_subject_params.pkl')

if 'extract_model_par' in analyzing_pipeline:
    extract_model_par(exp_folders[0])

if 'logit_vs_action_freq' in analyzing_pipeline:
    for exp_folder in exp_folders[:1]:
        logit_vs_action_freq(exp_folder)

if 'action_freq_after_action_seq' in analyzing_pipeline:
    for exp_folder in exp_folders:
        action_freq_after_action_seq(exp_folder)
# dynamics
for exp_folder in exp_folders:
    if 'run_scores_for_each_exp' in analyzing_pipeline:
        run_scores_exp(exp_folder, has_rnn=True, has_cog=False)
    if 'run_scores_for_each_exp_best_for_test' in analyzing_pipeline:
        run_scores_exp(exp_folder, best_for_test=True)
    if 'run_2d_inits_for_each_exp' in analyzing_pipeline:
        run_2d_inits_exp(exp_folder, grid_num=50)


if 'extract_1d_for_each_exp' in analyzing_pipeline:
    for exp_folder in exp_folders:
        extract_1d_logit_for_exp(exp_folder)

