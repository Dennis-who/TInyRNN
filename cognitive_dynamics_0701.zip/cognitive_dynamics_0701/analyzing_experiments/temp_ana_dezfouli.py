import pickle
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import pandas as pd
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegressionCV, LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV

import matplotlib as mpl
mpl.rcParams['font.size'] = 8
mpl.rcParams['pdf.fonttype'] = 42
mpl.rcParams['ps.fonttype'] = 42
mpl.rcParams['font.family'] = 'arial'
mpl.rcParams['savefig.dpi'] = 480

with open(r"C:\Users\lijia\Downloads\Telegram Desktop\diagnoses.pkl", "rb") as f:
    str_label = pickle.load(f)

with open(r"C:\Users\lijia\Downloads\Telegram Desktop\weights.pkl", "rb") as f:
    weights = pickle.load(f) # 1d RNN

with open(r"D:\OneDrive\Documents\git_repo\RP#0_RNN-behaviour\save\experiment\Dezfouli_RNN\weights.pkl", "rb") as f:
    weights2 = pickle.load(f) # 2d RNN

import joblib
weight_dt = joblib.load(r'D:\OneDrive\Documents\git_repo\cognitive_dynamics\files\analysis\exp_dezfouliAll\cog_subject_params.pkl')
dt=weight_dt[weight_dt['cog_type']=='MB0']
weights =[]
for sub in range(101):
    sub_dt = dt[dt['subject_number'] == sub]
    assert len(sub_dt) == 6
    avg_params = np.mean([np.array(sub_dt.iloc[i]['params']) for i in range(6)], axis=0)
    weights.append(avg_params)
X = np.array(weights)
print(X.shape)
print(X)
feat_names = np.array(['par'] * X.shape[1])

label_order = ['Healthy', 'Depression', 'Bipolar']
mapping = {label: idx for idx, label in enumerate(label_order)}
y_true = np.array([mapping[label] for label in str_label])

# X = []
# feat_names = np.array(['w (A1 R0)', 'w (A1 R1)', 'w (A2 R0)', 'w (A2 R1)', 'b (A1 R0)', 'b (A1 R1)', 'b (A2 R0)', 'b (A2 R1)', 'bias',])
# for sub_weights, sub_weights_2 in zip(weights, weights2):
#     sub_feat = []
#     for sub_fold_weight, sub_fold_weight2 in zip(sub_weights, sub_weights_2):
#         # svm = 0.36 for only recurrent weight
#         # svm = 0.39 for only recurrent bias
#         # svm = 0.47 for only recurrent weight and recurrent bias
#         # svm = 0.52 for all features
#         rec_weight = sub_fold_weight['_rnn._rnn_cell._weight'].flatten() # recurrent weight (4,)
#
#         rec_bias = sub_fold_weight['_rnn._rnn_cell._bias'].flatten() # recurrent bias (4,)
#         readout_weight = sub_fold_weight['_lin.weight'][0] - sub_fold_weight['_lin.weight'][1] # readout weight (1,)
#         readout_bias = sub_fold_weight['_lin.bias'][0:1] - sub_fold_weight['_lin.bias'][1:2] # readout bias (1,)
#         rec_bias = readout_weight * rec_bias # (4,)
#         # rec_bias += (1 - rec_weight) * readout_bias # (4,)
#         sub_fold_feat = [
#             rec_weight,
#             rec_bias,
#             readout_bias,
#         ]
#
#         # eigenvalues of recurrent weight
#         # for i in range(4):
#         #     # eigenvalues, _ = np.linalg.eig(sub_fold_weight2['_rnn._rnn_cell._weight'][:,:, i])
#         #     # eigenvalues = np.sort(eigenvalues)[::-1]
#         #     # sub_fold_feat.append(np.real(eigenvalues[:2]))
#         #     # singular values of recurrent weight
#         #     _, s, _ = np.linalg.svd(sub_fold_weight2['_rnn._rnn_cell._weight'][:,:, i])
#         #     s = np.sort(s)[::-1]
#         #     sub_fold_feat.append(s[:2])
#
#         sub_fold_feat = np.concatenate(sub_fold_feat)
#         sub_feat.append(sub_fold_feat)
#     sub_feat = np.mean(sub_feat, axis=0)
#     X.append(sub_feat)
# X = np.array(X)
# assert X.shape[1] == len(feat_names)

# import seaborn as sns
# import pandas as pd
# X_pd = pd.DataFrame(X, columns=feat_names)
# X_pd['diagnosis'] = str_label
# # displot
# # plt.figure(figsize=(1.5, 1.5))
# sns.displot(X_pd, x='b (A1 R0)', hue='diagnosis', kind='kde', height=1.5, aspect=1)
# plt.savefig(r"dezfouli_distribution_b_A1_R0.pdf", bbox_inches='tight')
# # sns.pairplot(X_pd, hue="diagnosis")
# plt.close()
# syss
# raise Exception

# tsne of X, with y_true as color and label
from sklearn.manifold import TSNE
# # pca
# from sklearn.decomposition import PCA
# pca = PCA(n_components=3)
# X_embedded = pca.fit_transform(X)
# explained_variance_ratio = pca.explained_variance_ratio_
# print(explained_variance_ratio)
# from mpl_toolkits.mplot3d import Axes3D
# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
# for label in np.unique(y_true):
#     idx = y_true == label
#     ax.scatter(X_embedded[idx, 0], X_embedded[idx, 1], X_embedded[idx, 2], label=label_order[label])
# ax.legend()
#
# plt.show()

# from sklearn.mixture import GaussianMixture
# classifiers = dict((covar_type, GaussianMixture(n_components=3,
#                     covariance_type=covar_type, max_iter=100))
#                    for covar_type in ['spherical', 'diag', 'tied', 'full']) # 0.3, 0.32, 0.39, 0.43 respectively


def wrap_train(X):

    def augment_X(X, y, switch_pairs, switch_signs):
        assert len(switch_pairs) == len(switch_signs)
        X_new = X.copy()
        y_new = y.copy()
        for pair, sign in zip(switch_pairs, switch_signs):
            X_new[:, pair[0]], X_new[:, pair[1]] = X[:, pair[1]] * sign, X[:, pair[0]] * sign
        return np.concatenate([X, X_new], axis=0), np.concatenate([y, y_new], axis=0)

    scaler = preprocessing.StandardScaler()
    y_pred = np.zeros_like(y_true)
    sub_coef = np.zeros([X.shape[0], 3, X.shape[1]])
    for loocv_sub_idx in range(X.shape[0]):
        X_train = np.delete(X, loocv_sub_idx, axis=0)
        X_train = scaler.fit_transform(X_train)
        y_train = np.delete(y_true, loocv_sub_idx, axis=0)
        X_test = scaler.transform(X[loocv_sub_idx:loocv_sub_idx+1])

        # classifier.means_ = np.array([X_train[y_train == i].mean(axis=0)
        #                               for i in range(3)])
        # clf.fit(X_train, y_train)

        # X_train, y_train = augment_X(X_train, y_train, [[0,2], [1,3], [4,6], [5,7],[8,8]], [1,1,-1,-1,-1])

        # clf = GridSearchCV(AdaBoostClassifier(), {'n_estimators': np.arange(1,20)}, cv=10, n_jobs=-1) # 0.37
        # clf = GridSearchCV(LogisticRegression(max_iter=1000), {'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000]}, cv=10, n_jobs=-1) # 0.47
        # clf = GridSearchCV(KNeighborsClassifier(), {'n_neighbors': np.arange(1,20)}, cv=10, n_jobs=-1) # 0.47
        print('subject', loocv_sub_idx)
        clf = GridSearchCV(SVC(kernel='linear'), {'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000
                                                        ]}, cv=10, n_jobs=-1) # 0.52
        clf.fit(X_train, y_train)
        print(loocv_sub_idx, 'best params:', clf.best_params_)
        clf = clf.best_estimator_
        y_pred[loocv_sub_idx:loocv_sub_idx+1] = clf.predict(X_test)
        sub_coef[loocv_sub_idx:loocv_sub_idx+1] = clf.coef_
        acc = (y_pred == y_true).mean()
    return acc, y_pred, sub_coef

acc, y_pred, sub_coef = wrap_train(X)
print('Accuracy: %.2f' % acc)

### partial acc
# acc_dict = {}
#
# acc, y_pred, sub_coef = wrap_train(X)
# acc_dict['full'] = acc
# print('Accuracy: %.2f' % acc)
# acc_dict['- w'] = wrap_train(np.delete(X, np.where([name.startswith('w') for name in feat_names])[0], axis=1))[0]
# acc_dict['- b'] = wrap_train(np.delete(X, np.where([name.startswith('b') for name in feat_names])[0], axis=1))[0]
# # acc_dict['- b (R0)'] = wrap_train(np.delete(X, np.where((feat_names == 'b (A1 R0)') | (feat_names == 'b (A2 R0)'))[0], axis=1))[0]
# # acc_dict['- b (R1)'] = wrap_train(np.delete(X, np.where((feat_names == 'b (A1 R1)') | (feat_names == 'b (A2 R1)'))[0], axis=1))[0]
# # acc_dict['- w (R0)'] = wrap_train(np.delete(X, np.where((feat_names == 'w (A1 R0)') | (feat_names == 'w (A2 R0)'))[0], axis=1))[0]
# # acc_dict['- w (R1)'] = wrap_train(np.delete(X, np.where((feat_names == 'w (A1 R1)') | (feat_names == 'w (A2 R1)'))[0], axis=1))[0]
#
# plt.figure(figsize=(0.8, 1.5))
# plt.bar(range(len(acc_dict)), acc_dict.values(), align='center', color='gray')
# plt.xticks(range(len(acc_dict)), acc_dict.keys(), rotation=90)
# plt.hlines(0.34, -0.5, len(acc_dict)-0.5, color='k', linestyle='--')
# plt.ylabel('LOOCV accuracy')
# plt.savefig(r"dezfouli_svm_partial_acc.pdf", bbox_inches='tight')
# plt.show()

### confusion matrix
# cm = confusion_matrix(y_true, y_pred)
# disp = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels=label_order)
# disp.plot()
# plt.title('Accuracy: %.2f' % (y_true == y_pred).mean())
# plt.show()

### feature importance
# def f_importances(coef, names):
#     imp = coef
#     imp,names = zip(*sorted(zip(imp,names))[::-1])
#     plt.figure(figsize=(1.5, 1.5))
#     plt.bar(range(len(names)), imp, align='center', color='gray')
#     plt.xticks(range(len(names)), names, rotation=90)
#     plt.ylabel('Feature importance')
#     plt.savefig(r"dezfouli_svm_feature_importance.pdf", bbox_inches='tight')
#     plt.show()
# f_importances(np.abs(sub_coef.mean(0)).mean(0), feat_names) # mean over subjects, then mean over 3 classifiers

