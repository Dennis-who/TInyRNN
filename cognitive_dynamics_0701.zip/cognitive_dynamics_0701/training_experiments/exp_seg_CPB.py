"""
Run all models on human subs with all hazard rates
"""
import sys
sys.path.append('..')
from training_experiments.training import *
from training_experiments.training_Nautilus_jobs_generation import *

base_config = {
      ### dataset info
      'dataset': 'CPBHuman',
      'behav_format': 'tensor',
      'behav_data_spec': {'max_segment_length': 30},
      ### model info
      'agent_type': 'RNN',
      'rnn_type': 'GRU', # which rnn layer to use

      'include_embedding': True,  # if False, then the embedding layer is ignored
      'num_embeddings': 58,
      'embedding_dim': 4,

      'input_dim': 3,# for normal input; assume normal input comes first, then subject
      'hidden_dim': 2, # dimension of this rnn layer
      'output_dim': 2, # dimension of action
      'device': 'cuda',
      'output_h0': True, # whether initial hidden state included in loss
      'trainable_h0': False, # the agent's initial hidden state trainable or not
      'readout_FC': True, # whether the readout layer is full connected or not
      'one_hot': False, # whether the data input is one-hot or not
      ### training info for one model
      'lr':0.005,
      'l1_weight': 1e-5,
      'weight_decay': 0,
      'penalized_weight': 'rec',
      'max_epoch_num': 2000,
      'early_stop_counter': 200,
      ### training info for many models on dataset
      'outer_splits': 5,
      'inner_splits': 4,
      'single_inner_fold': True,
      'seed_num': 5,
      ### additional training info
      'save_model_pass': 'minimal', # 'full' for saving all results; 'minimal' for saving only the losses; 'none' for not saving results
      'training_diagnose': None, # can be a list of diagnose function strings
      ### current training exp path
      'exp_folder': get_training_exp_folder_name(__file__),
}

config_ranges = { # keys are used to generate model names
      'rnn_type': ['GRU'],
      'hidden_dim': [
            100,50,20,10
                     ],
      'l1_weight': [1e-5],
      'include_embedding': [
                            True],
      'embedding_dim': [5,4,3,2,1],
}
resource_dict = {'memory': 16, 'cpu': 1, 'gpu': 1}
# behavior_cv_training_job_combination(base_config, config_ranges, resource_dict)
# behavior_cv_training_config_combination(base_config, config_ranges, n_jobs=1, verbose_level=1)

# behavior_cv_training_config_combination(base_config, config_ranges)


config_ranges.update({ # keys are used to generate model names
      'include_embedding': [False
                            ],
})
config_ranges.pop('embedding_dim')
# behavior_cv_training_job_combination(base_config, config_ranges, resource_dict)

# behavior_cv_training_config_combination(base_config, config_ranges, n_jobs=1, verbose_level=1)

# base_config.update({
#       'behav_data_spec': {'subjects': 'all', 'harzard_rates': 'all', 'max_segment_length': 150, 'input_noss': True},
# })
# config_ranges.update({
#       'hidden_dim': [20,10],
#       'input_dim': [3+11],
# })
# behavior_cv_training_config_combination(base_config, config_ranges)

base_config = {
      ### dataset info
      'dataset': 'CPBHuman',
      'behav_format': 'cog_session',
      'behav_data_spec': ['subjects', 'max_segment_length'],
      'max_segment_length': 30,
      # 'both' for all blocks
      ### model info
      'agent_type': 'CPBCog',
      'cog_type': 'MF',
      ### training info for one model
      ### training info for many models on dataset
      'outer_splits': 5,
      'inner_splits': 4,
      'single_inner_fold': True,
      'seed_num': 1,#5,
      ### additional training info
      'save_model_pass': 'minimal', # 'full' for saving all results; 'minimal' for saving only the losses; 'none' for not saving results
      'training_diagnose': None, # can be a list of diagnose function strings
      ### current training exp path
      'exp_folder': get_training_exp_folder_name(__file__),
}

config_ranges = {  # keys are also used to generate model names
      'subjects': list(range(58)),
      'cog_type': [
            # 'MF',
            'MB',
                   ],
}
if __name__ ==  '__main__' or '.' in __name__:
      behavior_cv_training_config_combination(base_config, config_ranges, n_jobs=1, verbose_level=1)