# joblib.dump({
#     'model': model,
#     'b_enc': model.b_enc,
#     'encoder': model.encoder,
#     'decoder': model.decoder,
#     'hidden_activations': hidden_activations,
#     'active_neuron_index': active_neuron_index,
#     'outputs': outputs,
#     'data': data, # concatenated data
#     'internal': internal, # list of n_trials x n_neurons
#     'behav_dt': behav_dt,
# }, 'sparse_autoencoder_all_results.pkl')
import joblib
import matplotlib.pyplot as plt
import numpy as np
import torch
from exp_SAE import *
import pandas as pd
import scipy.cluster.hierarchy as sch
import scipy.spatial.distance as spd
from anim_SAE import save_animation
goto_root_dir.run()

import numpy as np
import scipy.cluster.hierarchy as sch

# Assuming active_neurons and linkage_matrix are defined
import numpy as np
import scipy.cluster.hierarchy as sch


def sort_on_corr_sim(data): # n_trial, n_neurons
    df = pd.DataFrame(data)
    # distance_matrix = 1 - df.corr() # correlation distance
    # distance_matrix = 1 - spd.pdist(data.T, 'cosine') # cosine similarity between columns
    df = (df >0) * 1
    # euclidean distance between columns
    distance_matrix = spd.pdist(df.T, 'euclidean')
    distance_matrix = spd.squareform(distance_matrix)
    linkage_matrix = sch.linkage(distance_matrix, method='complete')

    # # Plot the dendrogram
    # dendrogram = sch.dendrogram(linkage_matrix, labels=[f"{i + 1}" for i in range(df.shape[1])])
    # plt.title('Dendrogram of Columns Based on Correlation')
    # plt.xlabel('Column Label')
    # plt.ylabel('Distance (1 - Correlation)')
    # plt.show()

    # Get the order of columns as per the clustering
    order = sch.leaves_list(linkage_matrix)
    return order


results = joblib.load(#'sparse_autoencoder_all_results_feature500_sparsitycoef2.pkl'
    'sae_all_results_feature500_sparsitycoef1_fWpenalty.pkl'
                      )
hidden_activations = results['hidden_activations'] # n_samples x n_hidden
w_dec = results['decoder'].weight # n_input x n_hidden
norm = torch.linalg.vector_norm(w_dec, ord=2, dim=0).reshape(1,-1) # 1 x n_hidden
hidden_activations = hidden_activations*norm # n_samples x n_hidden
active_neuron_index = results['active_neuron_index']
internal = results['internal']
behav_dt = results['behav_dt']
hidden_activations_active = hidden_activations[:,active_neuron_index].detach().numpy()

# plot 3 pca components
from sklearn.decomposition import PCA





order = sort_on_corr_sim(hidden_activations_active)
hidden_activations_active = hidden_activations_active[:,order]
trial_start = 0
index = 0
from matplotlib import pyplot as plt
for block in internal:
    trial_num = block.shape[0]
    trial_end = trial_start+trial_num
    plt.figure()
    hidden_activations_for_block = hidden_activations_active[trial_start:trial_end]
    sum_thre = 1
    active_neuron_index_for_block = np.where((hidden_activations_for_block.sum(0)>sum_thre))[0]
    behav_dt_block = behav_dt.behav
    action = behav_dt_block['action'][index]
    reward = behav_dt_block['reward'][index]
    sub_id = behav_dt_block['sub_id'][index][0]
    block_id = behav_dt_block['block'][index]
    plt.title(f'sub_id {sub_id} block_id {block_id}: trial {trial_start}-{trial_end}')
    assert len(action) == hidden_activations_for_block.shape[0] - 1, (len(action), hidden_activations_for_block.shape[0] - 1)

    # order again
    hidden_activations_for_block_active = hidden_activations_for_block[1:,active_neuron_index_for_block]
    order = sort_on_corr_sim(hidden_activations_for_block_active)
    hidden_activations_for_block_active = hidden_activations_for_block_active[:,order]
    active_neuron_index_for_block = active_neuron_index_for_block[order]

    pca = PCA(n_components=4)
    hidden_activations_active_pca = pca.fit_transform(hidden_activations_for_block_active)
    fig = plt.figure()
    plt.subplot(2, 1, 1)
    color_mapping ={
                    (1, 0): 'red',
                    (0, 0): 'blue',
                    (1, 1): 'green',
                    (0, 1): 'yellow'
                }
    plt.scatter(hidden_activations_active_pca[:, 0], hidden_activations_active_pca[:, 1],
                color=[color_mapping[(a, r)] for a, r in zip(action, reward)])
    plt.xlabel('PC1')
    plt.ylabel('PC2')
    plt.subplot(2, 1,2)
    plt.scatter(hidden_activations_active_pca[:, 2], hidden_activations_active_pca[:, 3],
                color=[color_mapping[(a, r)] for a, r in zip(action, reward)])
    plt.xlabel('PC3')
    plt.ylabel('PC4')
    plt.show()
    syss
    mat = np.concatenate((
                             action.reshape([1, -1]),  #shape: 1 x n_trials
                             reward.reshape([1, -1]),  #shape: 1 x n_trials
                             hidden_activations_for_block_active.T #shape: n_neurons x n_trials
                            ), axis=0)
    # for trial in range(trial_num-1):
    #     neuron_idx = 4
    #     print('trial', trial, 'action', action[trial], 'reward', reward[trial], f"neuron {active_neuron_index_for_block[neuron_idx]}'s activation", hidden_activations_for_block[trial+1,active_neuron_index_for_block[neuron_idx]])
    # syss
    # # subplots, with shared x-axis, each subplot is a neuron
    # colors = ['red' if r == 1 else 'blue' for r in mat[1]]
    # for i in range(0, mat.shape[0]-2):
    #     plt.subplot(mat.shape[0]-2, 1, i+1)
    #     plt.plot(mat[i+2])
    #     plt.ylabel(f'neuron {active_neuron_index_for_block[i]}', rotation=0, labelpad=20)
    #     # red for rewarded actions, blue for non-rewarded actions; scatter
    #     plt.scatter(range(trial_num-1), mat[0]*0.8+0.1, c=colors,s=5)
    # imshow with grid
    # plt.imshow(mat, cmap='Reds')
    # save_animation(mat, ['action', 'reward'] + list(active_neuron_index_for_block), window_size=20, fps=2, save_path=f'neuron_activation_sub{sub_id}_block{block_id}.gif')
    plt.pcolormesh(mat, edgecolors='gray', linewidth=2, cmap='Reds')
    ax = plt.gca()# invert y axis
    ax.invert_yaxis()
    # ax.grid(which='minor', color='k', linestyle='-', linewidth=2)
    yticks = ['action', 'reward'] + list(active_neuron_index_for_block)
    plt.yticks(0.5+np.arange(len(yticks)), yticks)
    plt.ylabel('neuron')
    plt.show()
    trial_start = trial_end
    index+=1
    if index >= 12:
        break

