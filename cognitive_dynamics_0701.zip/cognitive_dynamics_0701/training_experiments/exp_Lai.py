"""
Run all models on Lai Human.
"""
import sys
sys.path.append('..')
from training_experiments.training import *
from training_experiments.training_Nautilus_jobs_generation import *

base_config = {
      ### dataset info
      'dataset': 'LaiHuman',
      'behav_format': 'tensor',
      'behav_data_spec': {'group': [0,1]},
      ### model info
      'agent_type': 'RNN',
      'rnn_type': 'GRU', # which rnn layer to use
      'include_cond': True,
      'include_embedding': True, # if False, then the embedding layer is ignored
      'input_dim': 11, # for normal input; assume normal input comes first, then subject
      'num_embeddings': 85,
      'embedding_dim': 4,
      'hidden_dim': 20, # dimension of this rnn layer
      'output_dim': 3, # dimension of action
      'device': 'cuda',
      'output_h0': False, # whether initial hidden state included in loss
      'trainable_h0': False, # the agent's initial hidden state trainable or not
      'readout_FC': True, # whether the readout layer is full connected or not
      'one_hot': False, # whether the data input is one-hot or not
      ### training info for one model
      'lr':0.005,
      'l1_weight': 1e-5,
      'weight_decay': 0,
      'penalized_weight': 'rec',
      'max_epoch_num': 10000,
      'early_stop_counter': 200,
      ### training info for many models on dataset
      'outer_splits': 13,
      'inner_splits': 12,
      'single_inner_fold': True,
      'seed_num': 5,
      ### additional training info
      'save_model_pass': 'minimal', # 'full' for saving all results; 'minimal' for saving only the losses; 'none' for not saving results
      'training_diagnose': [], # can be a list of diagnose function strings
      ### current training exp path
      'exp_folder': get_training_exp_folder_name(__file__),
}

config_ranges = { # keys are used to generate model names
      'rnn_type': ['GRU'],
      'hidden_dim': [
            #20,50,10,5,
            #100
            200,400,500, 1000,
                     ],
      'l1_weight': [1e-5],
      'include_embedding': [
                            True],
      'embedding_dim': [5,4,3,2,1],
}

# behavior_cv_training_config_combination(base_config, config_ranges, n_jobs=1, verbose_level=1)

resource_dict = {'memory': 8, 'cpu': 1, 'gpu': 1}
# behavior_cv_training_job_combination(base_config, config_ranges, resource_dict)

config_ranges.update({ # keys are used to generate model names
      'include_embedding': [False
                            ],
})
config_ranges.pop('embedding_dim')
# behavior_cv_training_job_combination(base_config, config_ranges, resource_dict)
# behavior_cv_training_config_combination(base_config, config_ranges, n_jobs=1, verbose_level=1)

base_config = {
      ### dataset info
      'dataset': 'LaiHuman',
      'behav_format': 'cog_session',
      'behav_data_spec': ['subjects'],
      # 'both' for all blocks
      ### model info
      'agent_type': 'MemCog',
      'cog_type': 'AC3',
      'device': 'cpu',
      ### training info for one model
      ### training info for many models on dataset
      'outer_splits': 13,
      'inner_splits': 12,
      'single_inner_fold': True,
      'seed_num': 5,
      ### additional training info
      'save_model_pass': 'minimal', # 'full' for saving all results; 'minimal' for saving only the losses; 'none' for not saving results
      'training_diagnose': None, # can be a list of diagnose function strings
      ### current training exp path
      'exp_folder': get_training_exp_folder_name(__file__),
}

config_ranges = {  # keys are also used to generate model names
      'subjects': list(range(85)),
      'cog_type': [
            # 'AC3',
            'AC4'
      ],
}
if __name__ ==  '__main__' or '.' in __name__:
      behavior_cv_training_config_combination(base_config, config_ranges, n_jobs=-1, verbose_level=1)