import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# n_feat = 5  # Number of features
# n_trial = 100  # Number of trials
#
# np.random.seed(0)
# data = np.random.randn(n_feat, n_trial)

def save_animation(data, feat_label, window_size=10, fps=10, save_path='data_animation.gif'):
    n_feat, n_trial = data.shape
    fig, ax = plt.subplots()
    lines = [ax.plot(data[i, 0:1], label=feat_label[i])[0] for i in range(n_feat)]
    labels = [ax.text(0, 0, feat_label[i], va='center', ha='right') for i in range(n_feat)]
    ax.set_xlim(0, window_size)
    #ax.set_ylim(-3, 3)
    def update(frame):
        start_index = max(0, frame - window_size)  # Adjust the window size as needed
        end_index = frame + 1

        for i, line in enumerate(lines):
            x_data = np.arange(start_index, end_index)
            y_data = data[i, start_index:end_index]
            line.set_data(x_data, y_data)
            # Update text labels to follow the last data point
            labels[i].set_position((x_data[-1], y_data[-1]))
        ax.set_xlim(start_index, end_index)  # Scroll the x-axis
        ax.set_xticks(np.arange(start_index, end_index, 1))  # Update x-axis ticks
        return lines + labels

    ani = FuncAnimation(fig, update, frames=np.arange(n_trial), blit=True, interval=100)
    ani.save(save_path, writer='imagemagick', fps=fps)
    plt.show()
    plt.close()