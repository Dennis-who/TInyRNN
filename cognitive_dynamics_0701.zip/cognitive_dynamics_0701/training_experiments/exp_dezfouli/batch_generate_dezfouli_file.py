import os

source = 67
targets = [71, 75, 76, 77, 78, 84, 90, 92, 93, 94, 98, 100,]
for target in targets:
    with open(f'exp_dezfouli{source}.py', 'r') as reader:
        with open(f'exp_dezfouli{target}.py', 'w') as writer:
            for line in reader:
                line = line.replace(str(source), str(target))
                print(line, end='', file=writer)
#
for target in [source]+targets:
    print(f'python exp_dezfouli/exp_dezfouli{target}.py')

for target in [source]+targets:
    print(f'!python exp_dezfouli{target}.py')
