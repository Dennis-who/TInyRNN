import numpy as np
import torch
from torch import nn, optim
import joblib
# Define the Sparse Autoencoder
class SparseAutoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(SparseAutoencoder, self).__init__()
        self.b_enc = nn.Parameter(torch.randn(input_dim))
        self.encoder = nn.Linear(input_dim, hidden_dim)
        self.decoder = nn.Linear(hidden_dim, input_dim, bias=False) # w shape: input_dim x hidden_dim
        self.relu = nn.ReLU()

    def forward(self, x):
        h = self.relu(self.encoder(x-self.b_enc))
        y = self.decoder(h) + self.b_enc
        return y, h

# Loss function
def sparse_loss(outputs, targets, # n_samples x n_input
                hidden_activations, # n_samples x n_hidden
                w_dec, # n_input x n_hidden
                sparsity_coef):
    mse_loss = nn.MSELoss()
    n_sample, n_input = targets.shape
    reconstruction_loss = mse_loss(outputs, targets) * n_input # sum over n_input, then mean over n_sample
    norm = torch.linalg.vector_norm(w_dec, ord=2, dim=0).reshape(1,-1) # 1 x n_hidden
    sparsity_loss = torch.mean(torch.sum(torch.abs(hidden_activations)*norm,1)) # sum over n_hidden, then mean over n_sample
    return reconstruction_loss + sparsity_coef * sparsity_loss, reconstruction_loss, sparsity_loss

# Training function
def train_sparse_autoencoder(train_data, val_data, input_dim, hidden_dim, sparsity_param, epochs):
    model = SparseAutoencoder(input_dim, hidden_dim)
    optimizer = optim.AdamW(model.parameters(), lr=0.01)


    for epoch in range(epochs):
        optimizer.zero_grad()
        train_outputs, train_hidden_activations = model(train_data)
        total_loss = sparse_loss(train_outputs, train_data, train_hidden_activations,  model.decoder.weight,
                                 sparsity_param)
        train_loss, reconstruction_loss, sparsity_loss = total_loss
        train_loss.backward()
        optimizer.step()
        print(f'Epoch {epoch+1}, train loss: {train_loss.item():5f}, reconstruction: {reconstruction_loss.item():5f}, sparsity loss: {sparsity_loss.item():5f}, mean sparsity: {torch.mean(torch.sum(train_hidden_activations>0,1).float()).item():5f}',end=',')
        with torch.no_grad():
            val_outputs, val_hidden_activations = model(val_data)
            total_loss = sparse_loss(val_outputs, val_data, val_hidden_activations, model.decoder.weight,sparsity_param)
            val_loss, reconstruction_loss, sparsity_loss = total_loss
            print(f'val loss: {val_loss.item():5f}, reconstruction: {reconstruction_loss.item():5f}, sparsity loss: {sparsity_loss.item():5f}, mean sparsity: {torch.mean(torch.sum(val_hidden_activations>0,1).float()).item():5f}')
    return model
from datasets import Dataset
from utils import goto_root_dir
if __name__ == '__main__':
    goto_root_dir.run()
    behav_dt = Dataset('DezfouliHuman', behav_data_spec={'subject_number': 'all'})
    total_scores = joblib.load(r'D:\OneDrive\Documents\git_repo\cognitive_dynamics\files\analysis\exp_dezfouliAll\rnn_type-GRU.hidden_dim-50.readout_FC-True.l1_weight-1e-05.include_embedding-True.embedding_dim-3\outerfold0_innerfold0_seed4\total_scores.pkl')
    internal = total_scores['internal']# list of n_trials x n_neurons
    data = internal
    # train val split with sklearn
    from sklearn.model_selection import train_test_split
    train_data, val_data = train_test_split(data, test_size=0.2)
    print(len(train_data), len(val_data))
    data = np.concatenate(data)
    data = torch.tensor(data).float()
    train_data = np.concatenate(train_data)
    val_data = np.concatenate(val_data)
    train_data = torch.tensor(train_data).float()
    val_data = torch.tensor(val_data).float()

    input_dim = train_data.shape[1]
    hidden_dim = input_dim * 10
    sparsity_param = 1  # lambda
    epochs = 500

    # Train the model
    model = train_sparse_autoencoder(train_data, val_data, input_dim, hidden_dim, sparsity_param, epochs)

    from matplotlib import pyplot as plt
    outputs, hidden_activations = model(data)
    active_neuron_index = np.where((hidden_activations.sum(0)>0))[0]
    hidden_activations_active = hidden_activations[:,active_neuron_index]

    from utils import goto_root_dir
    goto_root_dir.run()
    joblib.dump({
        'b_enc': model.b_enc,
        'encoder': model.encoder,
        'decoder': model.decoder,
        'hidden_activations': hidden_activations,
        'active_neuron_index': active_neuron_index,
        'outputs': outputs,
        'data': data, # concatenated data
        'internal': internal, # list of n_trials x n_neurons
        'behav_dt': behav_dt,
    }, f'sae_all_results_feature{hidden_dim}_sparsitycoef{sparsity_param}_fWpenalty.pkl')
