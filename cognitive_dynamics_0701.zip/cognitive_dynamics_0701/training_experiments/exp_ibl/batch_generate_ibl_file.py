import os

source = 'IBL-T1'
targets = ['IBL-T4', 'NYU-01', 'NYU-02', 'NYU-04', 'CSHL_002', 'CSHL_003', 'CSHL_005', 'CSHL_007', 'CSHL_008', 'CSHL_010', 'CSHL_014', 'CSHL_015', 'KS003', 'ZM_1369', 'ZM_1371', 'ZM_1372', 'ZM_1743', 'ZM_1745', 'ibl_witten_04', 'ibl_witten_05', 'ibl_witten_06', 'ibl_witten_07', 'ibl_witten_12', 'ibl_witten_13', 'ibl_witten_16']
for target in targets:
    with open(f'exp_ibl{source}.py', 'r') as reader:
        with open(f'exp_ibl{target}.py', 'w') as writer:
            for line in reader:
                line = line.replace(source, target)
                print(line, end='', file=writer)
#
for target in [source]+targets:
    print(f'python exp_ibl/exp_ibl{target}.py')

for target in [source]+targets:
    print(f'!python exp_ibl{target}.py')
