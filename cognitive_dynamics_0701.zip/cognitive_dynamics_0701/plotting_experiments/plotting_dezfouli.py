from plotting import *
from plotting_dynamics import *
from plotting_decoding import *

save_pdf = True
plotting_pipeline = [
    # 'plot_model_perf_for_each_exp',
    # 'plot_perf_for_all_exps',
    # 'plot_dim_for_all_exps',
    # 'plot_model_num_par',
    'plot_dynamics_for_each_exp',
    # 'plot_1d_for_each_exp',
]
dynamics_plot_pipeline = [
    ## global options
    # 'relative_action', # note this option will change all results for 2d_logit_ and 2d_pr_ to relative action
    # 'hist', # note this option will change all results for 2d_logit_ and 2d_pr_ to histogram
    # 'show_curve', # show curve instead of dots; only for 1d models
    # 'legend', # show legend; only for 2d_logit_change and show_curve

    ## logit and pr analysis
    '2d_logit_change', # logit vs logit change
    # '2d_logit_next', # logit vs logit next
    # '2d_logit_nextpr', # logit vs pr next
    # '2d_pr_nextpr', # pr vs pr next
    # '2d_pr_change', # pr vs pr change
    # '2d_logit_nextpr_ci', # logit vs pr next with confidence interval; only for 1d models
    # '2d_logit_nextpr_ci_log_odds_ratio', # logit vs pr next, with log odds ratio calculated for confidence interval; only for 1d models

    ## other analysis
    # '2d_value_change',
    # '2d_vector_field',
    ]
exp_folders = [
'exp_dezfouliAll',
# 'exp_dezfouli67',
# 'exp_dezfouli71',
# 'exp_dezfouli75',
# 'exp_dezfouli76',
# 'exp_dezfouli77',
# 'exp_dezfouli78',
# 'exp_dezfouli84',
# 'exp_dezfouli90',
]

goto_root_dir.run()

dot_alpha = 0.8
markersize = 5
model_curve_setting = { # for monkey, all MBs are MFs
    'GRU': ModelCurve('GRU', 'GRU', 'C0', 0.6, 'x', markersize, 1, '-'),
    'SGRU': ModelCurve('SGRU', 'SGRU', 'C1', 0.6, 'x', markersize, 1, '-'),
    'PNR1': ModelCurve('SLIN', 'SLIN', 'C2', 0.6, 'x', markersize, 1, '-'),

    # MF: C4, LS: C5, MB/MFMB: C3, RC: C4
    'MFs': ModelCurve('MFs', 'MF', 'C4', dot_alpha, 'o', markersize, 1, '-'),
    'MB0s': ModelCurve('MBs', 'MF', 'C4', dot_alpha, 'o', markersize, 1, '-'),
    'MB0se': ModelCurve('MB0se', 'MF', 'C4', dot_alpha, 'o', markersize, 1, '-'),
    'LS0': ModelCurve('LS0', 'LS', 'C5', dot_alpha, 'v', markersize, 1, '-'),
    'LS1': ModelCurve('LS1', 'LS', 'C5', dot_alpha, 'v', markersize, 1, '-'),
    'MB0': ModelCurve('MB0', 'MF', 'C4',dot_alpha, 'o', markersize, 1, '-'),
    'MB1': ModelCurve('MB1', 'MF', 'C4', dot_alpha, 'o', markersize, 1, '-'),
    'MB0m': ModelCurve('MB0m', 'MF', 'C4',dot_alpha, 'o', markersize, 1, '-'),
    'MB0md': ModelCurve('MB-GRU', 'MF', 'C4', dot_alpha, 'o', markersize, 1, '-'),
    'RC': ModelCurve('RC', 'MF', 'C4', dot_alpha, 'o', markersize, 1, '-'),
    'Q(0)': ModelCurve('Q(0)', 'MF', 'C4', dot_alpha, 'o', markersize, 1, '-'),
    'Q(1)': ModelCurve('Q(1)', 'MF', 'C4', dot_alpha, 'o', markersize, 1, '-'),
}


def plot_all_model_losses(exp_folder, xlim=None, ylim=None,  xticks=None, yticks=None,
                          max_hidden_dim=20, minorticks=False, figsize=None, legend=True, perf_type='test_loss', title='', figname='loss_all_models',
                          model_curve_setting=None, add_text=False, save_pdf=True):

    if figsize is None:
        figsize = (1.5, 1.5)

    goto_root_dir.run()
    ana_exp_path = ANA_SAVE_PATH / exp_folder
    rnn_perf = joblib.load(ana_exp_path / 'rnn_final_perf.pkl')
    # cog_perf = joblib.load(ana_exp_path / 'cog_final_perf.pkl')
    # cog_perf = cog_perf[cog_perf['subjects'] == -1]
    fig, ax = plot_start(figsize=figsize)
    hidden_dims = pd.unique(rnn_perf['hidden_dim'])
    print(hidden_dims)
    embedding_dim_max = rnn_perf['embedding_dim'].max()
    # for cog_type in pd.unique(cog_perf['cog_type']):
    #     this_cog_perf = cog_perf[cog_perf['cog_type'] == cog_type]
    #     print(this_cog_perf['test_loss'])
    #     plt.plot([0,embedding_dim_max], [this_cog_perf['test_loss']]*2, label=cog_type)

    for hidden_dim in [10,20,50,100]:
        this_rnn_perf = rnn_perf[rnn_perf['hidden_dim'] == hidden_dim]
        embedding_dim = this_rnn_perf['embedding_dim']
        include_embedding = this_rnn_perf['include_embedding']
        embedding_dim *= include_embedding # set to 0 if not include_embedding
        perf = this_rnn_perf['test_loss']
        plt.plot(embedding_dim, perf, label=f'GRU({hidden_dim})')
    # cog perf
    if perf_type == 'test_loss':
        plt.ylabel('Negative log likelihood')
    plt.xlabel('# Embedding dimensions')
    # if yticks is not None:
    #     plt.yticks(yticks)
    # if ylim is not None:
    #     plt.ylim(ylim)
    if legend:
        leg = plt.legend(loc='center left', bbox_to_anchor=(1, 0.5), fancybox=True, shadow=False, ncol=1)
        # leg.set_title('Hidden units')
    plt.title(title)
    fig_exp_path = FIG_PATH / exp_folder
    os.makedirs(fig_exp_path, exist_ok=True)
    if add_text:
        figname = figname + '_text'
    figname = figname + ('.pdf' if save_pdf else '.png')
    plt.savefig(fig_exp_path / figname, bbox_inches="tight")
    plt.show()

plot_perf_exp_folders = exp_folders if 'plot_model_perf_for_each_exp' in plotting_pipeline else []
plot_perf_exp_folders += ['exp_dezfouli'] if 'plot_perf_for_all_exps' in plotting_pipeline else []
for exp_folder in plot_perf_exp_folders:
    # perf
    plot_all_model_losses(exp_folders[0])

    # for add_text in [True, False]:
    #     plot_all_model_losses(exp_folder,
    #                       rnn_types=['GRU', 'SGRU', #'PNR1'
    #                                  ],
    #                       cog_types=[
    #                           # 'MB0s',
    #                           #        'MB0', 'MB1', #'MB0md',#'MB0m',
    #                           #        'RC'
    #                                  ],
    #                       rnn_filters={'readout_FC': True},
    #                       xlim=[0.91, 22],
    #                       # ylim=[0.4, 0.55],
    #                       # yticks=[0.4, 0.5],
    #                       xticks=[1, 2, 3, 4, 5, 10, 20],
    #                       max_hidden_dim=20,
    #                       minorticks=False,
    #                       figsize=(1.5, 1.5),
    #                       legend=True,
    #                       title=exp_folder[4:],
    #                       figname='loss_all_models',
    #                       model_curve_setting=model_curve_setting,
    #                       add_text=add_text,
    #                       save_pdf=save_pdf,
    #                       )


if 'plot_dim_for_all_exps' in plotting_pipeline:
    plot_dim_distribution('exp_dezfouli')


    # dynamics
if 'plot_dynamics_for_each_exp' in plotting_pipeline:
    for exp_folder in exp_folders:
        plot_all_models_value_change(exp_folder, plots=dynamics_plot_pipeline,plot_max_logit=10, rnn_filters={'hidden_dim': 50, 'embedding_dim': 2}, plot_params={'s': 0.1, 'alpha': 0.2},
         save_pdf=save_pdf)

if 'plot_1d_for_each_exp' in plotting_pipeline:
    for exp_folder in exp_folders:
        # plot_1d_logit_coef(exp_folder)
        plot_1d_logit_feature_simple(exp_folder, save_pdf=save_pdf, legend=True, feature='intercept')
        plot_1d_logit_feature_simple(exp_folder, save_pdf=save_pdf, legend=False, feature='slope')

