from plotting import *
from plotting_dynamics import *

save_pdf = True
plotting_pipeline = [
    # 'plot_model_perf_for_each_exp',
    'embedding_correlation'
]
exp_folders = [
    'exp_Lai',
]

def plot_all_model_losses(exp_folder, xlim=None, ylim=None,  xticks=None, yticks=None,
                          max_hidden_dim=20, minorticks=False, figsize=None, legend=True, perf_type='test_loss', title='', figname='loss_all_models',
                          model_curve_setting=None, add_text=False, save_pdf=True):

    if figsize is None:
        figsize = (1.5, 1.5)

    goto_root_dir.run()
    ana_exp_path = ANA_SAVE_PATH / exp_folder
    rnn_perf = joblib.load(ana_exp_path / 'rnn_final_perf.pkl')
    cog_perf = joblib.load(ana_exp_path / 'cog_final_perf.pkl')
    cog_perf = cog_perf[cog_perf['subjects'] == -1]
    fig, ax = plot_start(figsize=figsize)
    hidden_dims = pd.unique(rnn_perf['hidden_dim'])
    print(hidden_dims)
    embedding_dim_max = rnn_perf['embedding_dim'].max()
    for cog_type in pd.unique(cog_perf['cog_type']):
        this_cog_perf = cog_perf[cog_perf['cog_type'] == cog_type]
        print(this_cog_perf['test_loss'])
        plt.plot([0,embedding_dim_max], [this_cog_perf['test_loss']]*2, label=cog_type)

    for hidden_dim in [100,200,400]:
        this_rnn_perf = rnn_perf[rnn_perf['hidden_dim'] == hidden_dim]
        embedding_dim = this_rnn_perf['embedding_dim']
        include_embedding = this_rnn_perf['include_embedding']
        embedding_dim *= include_embedding # set to 0 if not include_embedding
        perf = this_rnn_perf['test_loss']
        plt.plot(embedding_dim, perf, label=f'GRU({hidden_dim})')
    # cog perf
    if perf_type == 'test_loss':
        plt.ylabel('Negative log likelihood')
    plt.xlabel('# Embedding dimensions')
    # if yticks is not None:
    #     plt.yticks(yticks)
    # if ylim is not None:
    #     plt.ylim(ylim)
    if legend:
        leg = plt.legend(loc='center left', bbox_to_anchor=(1, 0.5), fancybox=True, shadow=False, ncol=1)
        # leg.set_title('Hidden units')
    plt.title(title)
    fig_exp_path = FIG_PATH / exp_folder
    os.makedirs(fig_exp_path, exist_ok=True)
    if add_text:
        figname = figname + '_text'
    figname = figname + ('.pdf' if save_pdf else '.png')
    plt.savefig(fig_exp_path / figname, bbox_inches="tight")
    plt.show()

if 'plot_model_perf_for_each_exp' in plotting_pipeline:
    plot_all_model_losses(exp_folders[0])

if 'embedding_correlation' in plotting_pipeline:
    path = "exp_Lai\\rnn_type-GRU.hidden_dim-50.l1_weight-1e-05.include_embedding-True.embedding_dim-1\\outerfold0_innerfold0_seed0"
    ag = transform_model_format(path, source='path', target='agent')

    for name, x in ag.model.named_parameters():
        if name == 'embedding.weight':
            print(name, x.shape)
            embedding = x
            break
    embedding = embedding.detach().cpu().numpy()
    # plt.scatter(embedding[:, 0], embedding[:, 1])
    # plt.show()

    dt = Dataset('LaiHuman',behav_data_spec={'group':[0,1]})
    sub_bias = dt.sub_bias
    # calculate the correlation between each embedding column and the subject bias column
    from scipy.stats import pearsonr
    for i in range(embedding.shape[1]):
        for j in range(sub_bias.shape[1]):
            r, p = pearsonr(embedding[:, i], sub_bias[:, j])
            if p < 0.05:
                print('embedding column %d, subject bias column %d, r=%.3f, p=%f' % (i, j, r, p))
    # calculate the correlation between each embedding column and the subject bias column mean
    for i in range(embedding.shape[1]):
        import seaborn as sns
        from scipy.stats import pearsonr
        fig, ax = plot_start()
        x=embedding[:, i]
        y=sub_bias.mean(axis=1)
        (r, p) = pearsonr(x, y)
        if p< 0.001: # scientific notation
            p = f'{p:.3e}'
        else:
            p = f'{p:.3f}'
        sns.regplot(x=x, y=y, fit_reg=True, label=r'$\rho$'+f'={r:.2f}, p={p}', scatter_kws={'s': 1})
        plt.xlabel('Embedding dimension %d' % i)
        # plt.xlim([0, 0.5])
        # plt.xticks([0, 0.5])
        plt.ylabel('Subject bias')
        plt.legend()
        plt.savefig(FIG_PATH / 'exp_Lai' / f'embedding_{i}_bias_corr.pdf', bbox_inches="tight")
        plt.close()