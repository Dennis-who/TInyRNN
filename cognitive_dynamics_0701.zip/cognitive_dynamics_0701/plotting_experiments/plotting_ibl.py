from plotting import *
from plotting_dynamics import *
from plotting_decoding import *
import matplotlib.cm as cm
from functools import partial

save_pdf = True
plotting_pipeline = [
    # 'plot_model_perf_for_each_exp',
    # 'plot_perf_for_all_exps',
    # 'plot_dim_for_all_exps',
    # 'plot_model_num_par',
    'plot_dynamics_for_each_exp',
    # 'plot_1d_for_each_exp',
]
dynamics_plot_pipeline = [
    ## global options
    # 'relative_action', # note this option will change all results for 2d_logit_ and 2d_pr_ to relative action
    # 'hist', # note this option will change all results for 2d_logit_ and 2d_pr_ to histogram
    # 'show_curve', # show curve instead of dots; only for 1d models
    'legend', # show legend; only for 2d_logit_change and show_curve

    ## logit and pr analysis
    # '2d_logit_change', # logit vs logit change
    '2d_logit_next', # logit vs logit next
    # '2d_logit_nextpr', # logit vs pr next
    # '2d_pr_nextpr', # pr vs pr next
    # '2d_pr_change', # pr vs pr change
    # '2d_logit_nextpr_ci', # logit vs pr next with confidence interval; only for 1d models
    # '2d_logit_nextpr_ci_log_odds_ratio', # logit vs pr next, with log odds ratio calculated for confidence interval; only for 1d models

    ## other analysis
    # '2d_value_change',
    # '2d_vector_field',
    ]
exp_folders = [
    # 'exp_iblIBL-T1',
    # 'exp_iblIBL-T4',
    'exp_iblNYU-01',
    # 'exp_iblNYU-02',
    'exp_iblNYU-04',
    'exp_iblCSHL_002',
    # 'exp_iblCSHL_003',
    # 'exp_iblCSHL_005',
    'exp_iblCSHL_007',
    # 'exp_iblCSHL_008',
    # 'exp_iblCSHL_010',
    'exp_iblCSHL_014',
    'exp_iblCSHL_015',
    # 'exp_iblKS003',
    # 'exp_iblZM_1369',
    # 'exp_iblZM_1371',
    # 'exp_iblZM_1372',
    # 'exp_iblZM_1743',
    # 'exp_iblZM_1745',
    # 'exp_iblibl_witten_04',
    # 'exp_iblibl_witten_05',
    # 'exp_iblibl_witten_06',
    # 'exp_iblibl_witten_07',
    # 'exp_iblibl_witten_12',
    # 'exp_iblibl_witten_13',
    # 'exp_iblibl_witten_16',
]

goto_root_dir.run()

dot_alpha = 0.8
markersize = 5
model_curve_setting = {
    'GRU': ModelCurve('GRU', 'GRU', 'C0', 0.6, 'x', markersize, 1, '-'),
}



def coloring_mapping(trial_types, color_type='stim'):
    # trial_types is a 2D array of shape (trial types, 3)
    # Define a vectorized version of the coloring_mapping function
    def _coloring_mapping(trial_type, color_type):
        # trial_type = ()
        action, reward, stim = trial_type
        if action>=0:  # valid trial type
            if color_type == 'stim':
                abs_stim = np.abs(stim)
                if np.isclose(abs_stim, 1):
                    color = 1
                elif np.isclose(abs_stim, 0.25):
                    color = 0.9
                elif np.isclose(abs_stim, 0.125):
                    color = 0.8
                elif np.isclose(abs_stim, 0.0625):
                    color = 0.7
                elif np.isclose(abs_stim, 0):
                    color = 0.5
                else:
                    raise ValueError('stim must be in [-1, 1]')
                if stim < 0:
                    color = 1 - color
                color = cm.get_cmap('PiYG')(color)
            elif color_type == 'action':
                color = np.array(['cornflowerblue', 'mediumblue', 'silver', 'dimgrey'])[int(action*2 + reward)]
            else:
                raise ValueError('color_type must be stim or action')
        else:  # invalid trial type, black
            color = 'k'
        return color

    colors = [_coloring_mapping(trial_type, color_type) for trial_type in trial_types]
    return colors
coloring_mapping_stim = partial(coloring_mapping, color_type='stim')
coloring_mapping_action = partial(coloring_mapping, color_type='action')

plot_perf_exp_folders = exp_folders if 'plot_model_perf_for_each_exp' in plotting_pipeline else []
plot_perf_exp_folders += ['exp_ibl'] if 'plot_perf_for_all_exps' in plotting_pipeline else []
for exp_folder in plot_perf_exp_folders:
    # perf
    for add_text in [True, False]:
        plot_all_model_losses(exp_folder,
                          rnn_types=['GRU',
                                     ],
                          cog_types=[],
                          rnn_filters={},
                          # xlim=[0.91, 22],
                          # ylim=[0.37, 0.51],
                          # yticks=[0.4, 0.45, 0.5],
                          # xticks=[1, 2, 3, 4, 5, 10, 20],
                          # max_hidden_dim=20,
                          minorticks=False,
                          figsize=(1.5, 1.5),
                          legend=True,
                          title=exp_folder[4:],
                          figname='loss_all_models',
                          model_curve_setting=model_curve_setting,
                          add_text=add_text,
                          save_pdf=save_pdf,
                          )

# dynamics
if 'plot_dynamics_for_each_exp' in plotting_pipeline:
    for exp_folder in exp_folders:
        plot_all_models_value_change(exp_folder, plots=dynamics_plot_pipeline,
         save_pdf=save_pdf, coloring_mapping=coloring_mapping_stim, plot_max_logit=8, output_h0=False, additional_fname='stimcolor')
        plot_all_models_value_change(exp_folder, plots=dynamics_plot_pipeline,
         save_pdf=save_pdf, coloring_mapping=coloring_mapping_action, plot_max_logit=8, output_h0=False, additional_fname='actioncolor')
        plot_all_models_value_change(exp_folder, plots=['2d_vector_field'],
                                     save_pdf=save_pdf, coloring_mapping=coloring_mapping_stim, plot_max_logit=8,
                                     output_h0=False, additional_fname='stimcolor')


if 'plot_1d_for_each_exp' in plotting_pipeline:
    for exp_folder in exp_folders:
        # plot_1d_logit_coef(exp_folder)
        plot_1d_logit_feature_simple(exp_folder, save_pdf=save_pdf, legend=True, feature='intercept')
        plot_1d_logit_feature_simple(exp_folder, save_pdf=save_pdf, legend=False, feature='slope')

